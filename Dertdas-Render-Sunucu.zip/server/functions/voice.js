import { createHmac } from 'node:crypto';
import { HttpsError } from 'firebase-functions/v2/https';
import { changeTokens, requireContact, validId, walletFor } from './account.js';

import { canJoinSession, spendSession } from './entitlements.js';

const duration = 15 * 60000;
const extension = 5 * 60000;
const extendCost = 10;
const giftPrices = new Map([['Teşekkür', 5], ['İyi ki dinledin', 10], ['Büyük destek', 25]]);

export async function voiceAction(db, uid, data, env = process.env) {
  const { action, callId, operationId } = data;
  if (!validId(callId)) throw new HttpsError('invalid-argument', 'Görüşme geçersiz.');
  const ref = db.doc('voiceCalls/' + callId);
  const turnUrl = env.VOICE_TURN_URL;
  const turnSecret = env.VOICE_TURN_SECRET;
  const view = (call, now) => ({
    ...call, other: call.members.find(member => member !== uid), offerer: call.speaker === uid,
    now, closed: !!call.closed || now >= (call.endsAt || call.startBy)
  });
  return db.runTransaction(async tx => {
    const now = Date.now();
    const call = (await tx.get(ref)).data();
    if (!call?.members.includes(uid)) throw new HttpsError('permission-denied', 'Görüşmeye erişilemiyor.');
    const current = view(call, now);
    const queue = call.members.map(member => db.doc('roomQueue/' + member));
    if (current.closed) return current;
    if (action === 'end') {
      const entries = await tx.getAll(...queue);
      tx.update(ref, { closed: true });
      entries.filter(entry => entry.get('callId') === callId).forEach(entry => tx.delete(entry.ref));
      return { ...current, closed: true };
    }
    await requireContact(db, tx, uid, current.other);
    if (action === 'voiceConfig') {
      if (!turnUrl || !turnSecret) throw new HttpsError('failed-precondition', 'Sesli görüşme sunucusu henüz yapılandırılmadı.');
      const username = Math.floor(now / 1000 + 3600) + ':' + uid;
      const credential = createHmac('sha1', turnSecret).update(username).digest('base64');
      return { ...current, iceServers: [{ urls: turnUrl.split(',').map(url => url.trim()), username, credential }] };
    }
    if (action === 'voiceStatus') return current;
    if (action === 'signal') {
      const { type, sdp } = data;
      const key = current.offerer ? 'offer' : 'answer';
      if (type !== key || typeof sdp !== 'string' || sdp.length > 45000 || !sdp.includes('m=audio') || /m=(video|application)/.test(sdp)) {
        throw new HttpsError('invalid-argument', 'Sesli bağlantı bilgisi geçersiz.');
      }
      if (call[key] && call[key] !== sdp) throw new HttpsError('failed-precondition', 'Bu görüşme başka bir cihazda açılmış.');
      tx.update(ref, { [key]: sdp });
      return view({ ...call, [key]: sdp }, now);
    }
    if (action === 'voiceConnected') {
      if (call.endsAt) return current;
      if (!call.offer || !call.answer) throw new HttpsError('failed-precondition', 'Ses bağlantısı hazırlanıyor.');
      const ready = [...new Set([...(call.ready || []), uid])];
      if (ready.length < 2) {
        tx.update(ref, { ready });
        return current;
      }
      const balances = await tx.getAll(...call.members.map(member => walletFor(db, member)));
      if (balances.some(balance => !canJoinSession(balance.data(), 'voice', now))) {
        throw new HttpsError('failed-precondition', 'Sesli görüşme için her katılımcının 50 jetonu veya VIP hakkı olmalı.');
      }
      const entries = await tx.getAll(...queue);
      call.members.forEach((member, index) =>
        spendSession(db, tx, member, balances[index].data(), 'voice', 'voice_' + callId, now));
      const endsAt = now + duration;
      tx.update(ref, { ready, startedAt: now, endsAt });
      entries.filter(entry => entry.get('callId') === callId).forEach(entry => tx.update(entry.ref, { until: endsAt }));
      return view({ ...call, endsAt, startedAt: now }, now);
    }
    if (!call.endsAt) throw new HttpsError('failed-precondition', 'Önce görüşme başlasın.');
    if (action === 'extensionRequest') {
      if (call.pendingExtension) return current;
      if (call.endsAt - now > 60000) throw new HttpsError('failed-precondition', 'Son bir dakikada süre isteyebilirsin.');
      const balance = await tx.get(walletFor(db, uid));
      if ((balance.get('tokens') || 0) < extendCost) throw new HttpsError('failed-precondition', 'Uzatma için 10 jeton gerekiyor.');
      tx.update(ref, { pendingExtension: uid });
      return { ...current, pendingExtension: uid };
    }
    if (action === 'extensionReject' || action === 'extensionAccept') {
      const payer = call.pendingExtension;
      if (!payer || payer === uid) throw new HttpsError('failed-precondition', 'Uzatma isteği bulunamadı.');
      if (action === 'extensionReject') {
        tx.update(ref, { pendingExtension: null });
        return { ...current, pendingExtension: null };
      }
      const [balance, ...entries] = await tx.getAll(walletFor(db, payer), ...queue);
      changeTokens(tx, db, payer, balance.data(), -extendCost, 'Sesli sohbet uzatma', 'extend_' + callId + '_' + call.endsAt);
      const endsAt = call.endsAt + extension;
      tx.update(ref, { endsAt, pendingExtension: null });
      entries.filter(entry => entry.get('callId') === callId).forEach(entry => tx.update(entry.ref, { until: endsAt }));
      return { ...current, endsAt, pendingExtension: null };
    }
    if (action === 'gift') {
      const cost = giftPrices.get(data.gift);
      if (!cost || !validId(operationId)) throw new HttpsError('invalid-argument', 'Hediye geçersiz.');
      const wallet = walletFor(db, uid);
      const ledgerId = 'gift_' + operationId;
      const [balance, existing] = await tx.getAll(wallet, wallet.collection('ledger').doc(ledgerId));
      if (existing.exists) return current;
      changeTokens(tx, db, uid, balance.data(), -cost, 'Hediye · ' + data.gift, ledgerId);
      const recentGifts = [...(call.recentGifts || []), { uid, label: data.gift, id: operationId }].slice(-12);
      tx.update(ref, { recentGifts });
      return { ...current, recentGifts };
    }
    throw new HttpsError('invalid-argument', 'İşlem geçersiz.');
  });
}
