import { changeTokens, tokens, walletFor } from './account.js';

export const vipPlans = new Map([
  ['vip_sari', { written: 5 }],
  ['vip_mavi', { written: 10 }],
  ['vip_mor', { written: 20 }]
]);

const turkeyDate = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Europe/Istanbul', year: 'numeric', month: '2-digit', day: '2-digit'
});

export function monthlyPasses(wallet, now) {
  const plan = wallet?.vipUntilMs > now && vipPlans.get(wallet.vipPlan);
  if (!plan) return { written: 0 };
  return {
    written: Math.max(0, plan.written - (wallet.vipWrittenUsed || 0))
  };
}

export function quoteSession(wallet, now) {
  const day = turkeyDate.format(now);
  if (wallet?.freeWrittenDay !== day) return { cost: 0, source: 'daily', day };
  if (monthlyPasses(wallet, now).written > 0) return { cost: 0, source: 'vip' };
  return { cost: 25, source: 'tokens' };
}

export function canJoinSession(wallet, now) {
  return tokens(wallet) >= quoteSession(wallet, now).cost;
}

export function spendSession(db, tx, uid, wallet, operation, now) {
  const quote = quoteSession(wallet, now);
  const ref = walletFor(db, uid);
  if (quote.source === 'daily') tx.set(ref, { freeWrittenDay: quote.day }, { merge: true });
  else if (quote.source === 'vip') {
    tx.set(ref, { vipWrittenUsed: (wallet.vipWrittenUsed || 0) + 1 }, { merge: true });
  } else changeTokens(tx, db, uid, wallet, -quote.cost, 'Yazılı görüşme', operation);
  return quote;
}
