import { changeTokens, tokens, walletFor } from './account.js';

export const vipPlans = new Map([
  ['vip_sari', { written: 5, voice: 1 }],
  ['vip_mavi', { written: 10, voice: 2 }],
  ['vip_mor', { written: 20, voice: 4 }]
]);

const turkeyDate = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Europe/Istanbul', year: 'numeric', month: '2-digit', day: '2-digit'
});

export function monthlyPasses(wallet, now) {
  const plan = wallet?.vipUntilMs > now && vipPlans.get(wallet.vipPlan);
  if (!plan) return { written: 0, voice: 0 };
  return {
    written: Math.max(0, plan.written - (wallet.vipWrittenUsed || 0)),
    voice: Math.max(0, plan.voice - (wallet.vipVoiceUsed || 0))
  };
}

export function quoteSession(wallet, kind, now) {
  const day = turkeyDate.format(now);
  if (kind === 'written' && wallet?.freeWrittenDay !== day) return { cost: 0, source: 'daily', day };
  if (monthlyPasses(wallet, now)[kind] > 0) return { cost: 0, source: 'vip' };
  return { cost: kind === 'voice' ? 50 : 25, source: 'tokens' };
}

export function canJoinSession(wallet, kind, now) {
  return tokens(wallet) >= quoteSession(wallet, kind, now).cost;
}

export function spendSession(db, tx, uid, wallet, kind, operation, now) {
  const quote = quoteSession(wallet, kind, now);
  const ref = walletFor(db, uid);
  if (quote.source === 'daily') tx.set(ref, { freeWrittenDay: quote.day }, { merge: true });
  else if (quote.source === 'vip') {
    const field = kind === 'voice' ? 'vipVoiceUsed' : 'vipWrittenUsed';
    tx.set(ref, { [field]: (wallet[field] || 0) + 1 }, { merge: true });
  } else changeTokens(tx, db, uid, wallet, -quote.cost, kind === 'voice' ? 'Sesli görüşme' : 'Yazılı görüşme', operation);
  return quote;
}
