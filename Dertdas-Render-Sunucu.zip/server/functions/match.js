import { canJoinSession, quoteSession } from './entitlements.js';
const roomIds = new Set(['recovery', 'family', 'relationships', 'talk', 'work', 'general', 'loneliness']);
const requestIdPattern = /^[a-f0-9-]{36}$/i;
const leaseMs = 25000;
const searchMs = 90000;
const connectMs = 90000;
const priorityRooms = new Set(['family', 'talk']);

function balance(wallet) {
  return Number.isSafeInteger(wallet?.tokens) && wallet.tokens >= 0 ? wallet.tokens : 0;
}

export async function processMatch(db, uid, data, HttpsError) {
  const { action, room, role, requestId, priority = false } = data || {};
  if (!['join', 'status', 'leave', 'claim', 'available'].includes(action)
      || !roomIds.has(room) || (action !== 'available' && (typeof requestId !== 'string' || !requestIdPattern.test(requestId)))
      || (action === 'join' && (!['speaker', 'listener'].includes(role) || typeof priority !== 'boolean'
        || (priority && (role !== 'speaker' || !priorityRooms.has(room)))))) {
    throw new HttpsError('invalid-argument', 'Eşleşme isteği geçersiz.');
  }

  const queue = db.collection('roomQueue');
  const wallet = db.collection('roomWallets');
  const myEntry = queue.doc(uid);
  const eligibilityDocs = id => [
    db.doc('consents/' + id),
    db.doc('suspensions/' + id),
    db.doc('deletionRequests/' + id), db.doc('adultConfirmations/' + id)
  ];
  const eligible = ([consent, suspension, deletion, adult]) =>
    consent.get('version') === '2026-11' && !suspension.exists && !deletion.exists && adult.get('confirmed') === true;

  return db.runTransaction(async tx => {
    const now = Date.now();
    const [mine, myBalance, ...myEligibility] = await tx.getAll(myEntry, wallet.doc(uid), ...eligibilityDocs(uid));
    if (action === 'available') {
      const listeners = await tx.get(queue.where('roomRole', '==', room + ':listener')
        .where('until', '>', now).orderBy('until').limit(100));
      const uidList = listeners.docs.map(doc => doc.id).filter(id => id !== uid);
      return { listeners: uidList.length };
    }
    if (!eligible(myEligibility)) throw new HttpsError('failed-precondition', 'Sesli eşleşme için 18 yaş ve üzeri olman gerekiyor.');
    const current = mine.data();
    const myWallet = myBalance.data();
    const withBalance = state => ({ ...state, tokens: balance(myWallet) });
    const sameRequest = current?.room === room && current.requestId === requestId;
    const currentMatch = current?.state === 'matched' && current.callId && current.until > now;
    if (currentMatch && current.room === room && (sameRequest || action === 'join')) {
      if (action === 'claim' && !current.claimed) tx.update(myEntry, { claimed: true });
      return withBalance({
        state: 'matched', other: current.other, callId: current.callId, requestId: current.requestId
      });
    }

    if (action === 'leave') {
      if (sameRequest && current.state === 'waiting') tx.delete(myEntry);
      return withBalance({ state: 'idle' });
    }
    if (action === 'claim') return withBalance({ state: 'idle' });
    if (currentMatch) {
      throw new HttpsError('failed-precondition', 'Önce diğer odadaki görüşmeni tamamla.');
    }

    const waiting = sameRequest && current.state === 'waiting' && current.until > now;
    if (action === 'status' && !waiting) return withBalance({ state: 'idle' });
    const searchRole = waiting ? current.role : role;
    const myPriority = waiting ? current.priority === true : priority;
    if (!canJoinSession(myWallet, 'voice', now)) {
      return withBalance({ state: 'funds', cost: quoteSession(myWallet, 'voice', now).cost });
    }

    const opposite = searchRole === 'speaker' ? 'listener' : 'speaker';
    const findCandidates = suffix => tx.get(queue.where('roomRole', '==', room + ':' + opposite + suffix)
      .where('until', '>', now).orderBy('until').limit(8));
    const regular = await findCandidates('');
    const preferred = searchRole === 'listener' && priorityRooms.has(room) ? await findCandidates(':priority') : null;

    for (const candidate of [...(preferred?.docs || []), ...regular.docs]) {
      const other = candidate.id;
      if (other === uid) continue;
      const [theirWallet, myBlock, theirBlock, ...theirEligibility] = await tx.getAll(
        wallet.doc(other), db.doc('users/' + uid + '/blocks/' + other),
        db.doc('users/' + other + '/blocks/' + uid), ...eligibilityDocs(other)
      );
      if (myBlock.exists || theirBlock.exists || !eligible(theirEligibility)) continue;

      const speaker = searchRole === 'speaker' ? uid : other;
      if (!canJoinSession(theirWallet.data(), 'voice', now)) continue;
      const call = db.collection('voiceCalls').doc();
      const priority = speaker === uid ? myPriority : candidate.get('priority') === true;
      const startBy = now + connectMs;
      tx.create(call, { members: [uid, other].sort(), speaker, priority, room, startBy });
      const matched = { state: 'matched', room, callId: call.id, until: startBy, claimed: false };
      tx.set(myEntry, { ...matched, requestId, other });
      tx.set(candidate.ref, { ...matched, requestId: candidate.get('requestId'), other: uid });
      return withBalance({ state: 'matched', other, callId: call.id, requestId });
    }

    const deadline = waiting ? current.deadline : now + searchMs;
    if (deadline <= now) return withBalance({ state: 'idle' });
    tx.set(myEntry, {
      state: 'waiting', room, roomRole: room + ':' + searchRole + (myPriority ? ':priority' : ''),
      role: searchRole, priority: myPriority, requestId, deadline,
      until: Math.min(now + leaseMs, deadline)
    });
    return withBalance({ state: 'waiting', role: searchRole });
  });
}
