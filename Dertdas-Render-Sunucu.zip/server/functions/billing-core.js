import { createHash } from 'node:crypto';
import { HttpsError } from 'firebase-functions/v2/https';
import { monthlyPasses, vipPlans, quoteSession } from './entitlements.js';
import { changeTokens, tokens, walletFor } from './account.js';

const products = new Map([['jeton_25', 25], ['jeton_35', 35], ['jeton_50', 50], ['jeton_100', 100]]);
const legacySub = 'sinirsiz_mesaj';
const packageName = 'com.dertdas.app';
const hash = text => createHash('sha256').update(text).digest('hex');

export function createBilling(publisher) {
  const play = (path, method) => publisher('purchases/' + path, method);

  async function authorizeCheckout(db, uid, product) {
    if (!vipPlans.has(product) && !products.has(product)) throw new HttpsError('invalid-argument', 'Ürün geçersiz.');
    const subscription = vipPlans.has(product);
    if (subscription) {
      const wallet = await walletFor(db, uid).get();
      if (wallet.get('vipUntilMs') > Date.now() || wallet.get('unlimitedUntil') > Date.now()) {
        return { state: 'subscribed' };
      }
    }
    try {
      await publisher((subscription ? 'subscriptions/' : 'oneTimeProducts/') + product);
      return { state: 'ready' };
    } catch (error) {
      const status = error.response?.status;
      if (status === 404) return { state: 'missing' };
      if (status === 401 || status === 403) return { state: 'setup' };
      return { state: 'retry' };
    }
  }

  async function walletStatus(db, uid) {
    const ref = walletFor(db, uid);
    const [snap, ledger] = await Promise.all([ref.get(), ref.collection('ledger').orderBy('createdAt', 'desc').limit(20).get()]);
    const now = Date.now();
    return { tokens: tokens(snap.data()), catalogVersion: 16, unlimitedUntil: snap.get('unlimitedUntil') || 0,
      vipPlan: snap.get('vipUntilMs') > now ? snap.get('vipPlan') : null,
      vipUntil: snap.get('vipUntilMs') || 0, passes: monthlyPasses(snap.data(), now),
      writtenPrice: quoteSession(snap.data(), now).cost,
      history: ledger.docs.map(doc => ({ amount: doc.get('amount'), reason: doc.get('reason'), date: doc.get('createdAt').toMillis() })) };
  }

  async function purchase(db, uid, { product, purchaseToken }) {
    const subscription = vipPlans.has(product) || product === legacySub;
    if ((!products.has(product) && !subscription) || typeof purchaseToken !== 'string' || purchaseToken.length < 5 || purchaseToken.length > 4096) {
      throw new HttpsError('invalid-argument', 'Satın alma bilgisi geçersiz.');
    }
    const key = hash(purchaseToken);
    const ref = db.doc('playReceipts/' + key);
    const wallet = walletFor(db, uid);
    const id = encodeURIComponent(purchaseToken);
    const itemPath = 'products/' + product + '/tokens/' + id;
    const details = await play(subscription ? 'subscriptionsv2/tokens/' + id : itemPath);
    const owner = subscription ? details.externalAccountIdentifiers?.obfuscatedExternalAccountId : details.obfuscatedExternalAccountId;
    if (owner !== hash(uid)) throw new HttpsError('permission-denied', 'Satın alma başka bir Dertdaş hesabına ait.');
    if (subscription) {
      const line = details.lineItems?.find(line => line.productId === product);
      if (!line) throw new HttpsError('failed-precondition', 'Abonelik bulunamadı.');
      const expiry = Date.parse(line.expiryTime || '');
      const active = ['SUBSCRIPTION_STATE_ACTIVE', 'SUBSCRIPTION_STATE_CANCELED', 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD'].includes(details.subscriptionState);
      const until = active && Number.isFinite(expiry) && expiry > Date.now() ? expiry : 0;
      await db.runTransaction(async tx => {
        const [receipt, current] = await tx.getAll(ref, wallet);
        if (receipt.exists && receipt.get('uid') !== uid) throw new HttpsError('permission-denied', 'Satın alma başka bir hesaba ait.');
        if (product === legacySub) {
          if (!current.get('playSubscription') || current.get('playSubscription') === key || until > (current.get('unlimitedUntil') || 0)) {
            tx.set(wallet, { playSubscription: key, unlimitedUntil: until }, { merge: true });
          }
        } else {
          const existing = current.get('vipSubscription');
          const order = line.latestSuccessfulOrderId || details.latestOrderId;
          const lastExpiry = receipt.get('lastExpiry') || 0;
          if (until && (!order || expiry < lastExpiry)) return;
          if (existing === key || (!current.get('vipUntilMs') && until) || until > (current.get('vipUntilMs') || 0)) {
            const renewed = until && order !== current.get('vipOrder');
            const quotaReset = renewed ? { vipWrittenUsed: 0, vipOrder: order } : {};
            tx.set(wallet, { vipPlan: product, vipUntilMs: until, vipSubscription: key, ...quotaReset }, { merge: true });
          }
          tx.set(ref, { lastExpiry: Math.max(lastExpiry, until) }, { merge: true });
        }
        tx.set(ref, { uid, product }, { merge: true });
      });
      if (until && details.acknowledgementState === 'ACKNOWLEDGEMENT_STATE_PENDING') {
        await play('subscriptions/' + product + '/tokens/' + id + ':acknowledge', 'POST');
      }
    } else {
      if (details.purchaseState !== 0 && details.purchaseState !== 1) {
        throw new HttpsError('failed-precondition', 'Google Play ödemeyi bekliyor.');
      }
      await db.runTransaction(async tx => {
        const [receipt, current] = await tx.getAll(ref, wallet);
        if (receipt.exists && receipt.get('uid') !== uid) throw new HttpsError('permission-denied', 'Satın alma başka bir hesaba ait.');
        if (details.purchaseState === 1) {
          if (receipt.get('status') === 'credited') {
            const amount = receipt.get('amount');
            tx.set(wallet, { tokens: (current.get('tokens') || 0) - amount }, { merge: true });
            tx.create(wallet.collection('ledger').doc('refund_' + key), { amount: -amount, reason: 'Google Play iadesi', createdAt: new Date() });
          }
          tx.set(ref, { uid, product, status: 'refunded' }, { merge: true });
        } else if (!receipt.exists) {
          if (details.consumptionState === 1) throw new HttpsError('failed-precondition', 'Satın alma daha önce kullanılmış.');
          const amount = products.get(product) * (details.quantity || 1);
          changeTokens(tx, db, uid, current.data(), amount, 'Jeton satın alma', 'play_' + key);
          tx.create(ref, { uid, product, amount, status: 'credited' });
        }
      });
      if (details.purchaseState === 0 && details.consumptionState !== 1) await play(itemPath + ':consume', 'POST');
    }
    return walletStatus(db, uid);
  }

  async function playNotification(db, data) {
    if (data?.packageName !== packageName) return;
    const event = data.subscriptionNotification || data.oneTimeProductNotification || data.voidedPurchaseNotification;
    if (!event?.purchaseToken) return;
    const ref = db.doc('playReceipts/' + hash(event.purchaseToken));
    const receipt = await ref.get();
    if (!receipt.exists) return;
    const owner = receipt.get('uid');
    const [consent, deletion] = await db.getAll(db.doc('consents/' + owner), db.doc('deletionRequests/' + owner));
    if (!consent.exists || deletion.exists) return;
    if (data.voidedPurchaseNotification && products.has(receipt.get('product'))) {
      // Full refunds are recorded once, independent of product lookup retention.
      if (event.refundType !== 1) {
        console.warn('Kısmi iade için operatör incelemesi gerekli.');
        return;
      }
      await db.runTransaction(async tx => {
        const row = await tx.get(ref);
        if (row.get('status') !== 'credited') return;
        const wallet = walletFor(db, row.get('uid'));
        const current = await tx.get(wallet);
        const amount = row.get('amount');
        tx.set(wallet, { tokens: (current.get('tokens') || 0) - amount }, { merge: true });
        tx.create(wallet.collection('ledger').doc('refund_' + row.id), { amount: -amount, reason: 'Google Play iadesi', createdAt: new Date() });
        tx.update(ref, { status: 'refunded' });
      });
      return;
    }
    await purchase(db, receipt.get('uid'), { product: receipt.get('product'), purchaseToken: event.purchaseToken });
  }
  return { authorizeCheckout, walletStatus, purchase, playNotification };
}
