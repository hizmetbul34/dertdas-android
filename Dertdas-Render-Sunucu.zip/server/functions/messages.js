import { createHash } from 'node:crypto';
import { HttpsError } from 'firebase-functions/v2/https';
import { changeTokens, requireContact, tokens, validId, walletFor } from './account.js';

const prices = new Map([[15, 25], [25, 35], [50, 50]]);
const freeMessages = 5;
const idFor = users => createHash('sha256').update(JSON.stringify(users)).digest('hex');

function status(chat, uid, wallet) {
  return {
    id: chat.id, state: chat.state || 'accepted', initiator: chat.initiator || '',
    remaining: Math.max(0, freeMessages - (chat.freeUsed || 0)) + (chat.paidRemaining || 0),
    unlimited: (wallet?.unlimitedUntil || 0) > Date.now(), tokens: tokens(wallet)
  };
}

export async function messageAction(db, uid, data) {
  const { action, other, chatId, operationId, messageId, pack } = data;
  if (action === 'profileSearch') {
    const handle = String(data.handle || '').toLowerCase();
    if (!/^[a-z0-9_]{3,24}$/.test(handle)) return {};
    const found = await db.doc('publicHandles/' + handle).get();
    if (!found.exists || found.get('uid') === uid) return {};
    await db.runTransaction(tx => requireContact(db, tx, uid, found.get('uid')));
    return { uid: found.get('uid'), handle };
  }
  if (action === 'setHandle') {
    const handle = String(data.handle || '').toLowerCase();
    if (!/^[a-z0-9_]{3,24}$/.test(handle)) throw new HttpsError('invalid-argument', '3–24 harf, rakam veya alt çizgi kullan.');
    return db.runTransaction(async tx => {
      const profile = db.doc('users/' + uid);
      const ref = db.doc('publicHandles/' + handle);
      const [mine, existing] = await tx.getAll(profile, ref);
      if (existing.exists && existing.get('uid') !== uid) throw new HttpsError('already-exists', 'Bu kullanıcı adı kullanımda.');
      const previous = mine.get('handle');
      if (typeof previous === 'string' && /^[a-z0-9_]{3,24}$/.test(previous) && previous !== handle) {
        const old = await tx.get(db.doc('publicHandles/' + previous));
        if (old.get('uid') === uid) tx.delete(old.ref);
      }
      tx.set(ref, { uid });
      tx.set(profile, { handle }, { merge: true });
      return { handle };
    });
  }

  const wallet = walletFor(db, uid);
  if (action === 'open' && (!validId(other) || other === uid)) throw new HttpsError('invalid-argument', 'Kullanıcı geçersiz.');
  if (action !== 'open' && !validId(chatId)) throw new HttpsError('invalid-argument', 'Sohbet geçersiz.');
  const members = action === 'open' ? [uid, other].sort() : null;
  return db.runTransaction(async tx => {
    let ref = db.doc('chats/' + (members ? idFor(members) : chatId));
    let [chat, balance] = await tx.getAll(ref, wallet);
    if (members) {
      await requireContact(db, tx, uid, other);
      // V13 direct chats used a deterministic ID. Reuse them and their history.
      if (!chat.exists) {
        const old = await tx.get(db.doc('chats/' + members.join('_')));
        if (old.exists && old.get('members')?.join('\n') === members.join('\n')) {
          chat = old;
          ref = old.ref;
        }
      }
      if (!chat.exists) return { id: ref.id, state: 'new', initiator: uid, remaining: freeMessages, tokens: tokens(balance.data()) };
    }
    if (!chat.exists && action === 'send' && validId(other) && other !== uid && idFor([uid, other].sort()) === chatId) {
      await requireContact(db, tx, uid, other);
      if (!validId(operationId)) throw new HttpsError('invalid-argument', 'İşlem geçersiz.');
      const text = cleanText(data.text);
      const state = { members: [uid, other].sort(), initiator: uid, state: 'pending', freeUsed: 1, paidRemaining: 0, updatedAt: new Date() };
      tx.create(ref, state);
      tx.create(ref.collection('messages').doc(operationId), { uid, text, createdAt: new Date() });
      return status({ ...state, id: ref.id }, uid, balance.data());
    }
    const fields = chat.data();
    if (!fields?.members?.includes(uid)) throw new HttpsError('permission-denied', 'Sohbete erişilemiyor.');
    const peer = fields.members.find(id => id !== uid);
    const initiator = fields.initiator || uid;
    const result = status({ ...fields, id: ref.id }, uid, balance.data());
    if (action === 'open' || action === 'status') return result;
    const prefs = db.doc('users/' + uid + '/chatPrefs/' + ref.id);
    if (action === 'hide' || action === 'unhide') {
      tx.set(prefs, { hidden: action === 'hide' }, { merge: true });
      return result;
    }
    if (action === 'unsend') {
      if (!validId(messageId)) throw new HttpsError('invalid-argument', 'Mesaj geçersiz.');
      const msg = await tx.get(ref.collection('messages').doc(messageId));
      if (!msg.exists || msg.get('uid') !== uid) throw new HttpsError('permission-denied', 'Mesajı geri alamazsın.');
      tx.update(msg.ref, { text: '', unsent: true });
      return result;
    }
    if (action === 'send' && validId(operationId) && (await tx.get(ref.collection('messages').doc(operationId))).exists) return result;
    await requireContact(db, tx, uid, peer);
    if (action === 'accept' || action === 'decline') {
      if (fields.state !== 'pending' || fields.initiator === uid) throw new HttpsError('failed-precondition', 'Mesaj isteği bulunamadı.');
      const state = action === 'accept' ? 'accepted' : 'declined';
      tx.update(ref, { state });
      return { ...result, state };
    }
    if (result.state !== 'accepted') throw new HttpsError('failed-precondition', 'Önce mesaj isteğinin kabul edilmesi gerekiyor.');
    if (!validId(operationId)) throw new HttpsError('invalid-argument', 'İşlem geçersiz.');
    if (action === 'pack') {
      if (uid !== initiator || !prices.has(pack)) throw new HttpsError('invalid-argument', 'Mesaj paketi geçersiz.');
      const ledgerId = 'messages_' + operationId;
      if ((await tx.get(wallet.collection('ledger').doc(ledgerId))).exists) return result;
      const newBalance = changeTokens(tx, db, uid, balance.data(), -prices.get(pack), 'Mesaj paketi', ledgerId);
      tx.update(ref, { initiator, paidRemaining: (fields.paidRemaining || 0) + pack });
      return { ...result, initiator, remaining: result.remaining + pack, tokens: newBalance };
    }
    if (action !== 'send') throw new HttpsError('invalid-argument', 'İşlem geçersiz.');
    const msg = ref.collection('messages').doc(operationId);
    const text = cleanText(data.text);
    const updates = { updatedAt: new Date(), initiator };
    if (uid === initiator && !result.unlimited) {
      if ((fields.freeUsed || 0) < freeMessages) updates.freeUsed = (fields.freeUsed || 0) + 1;
      else if (fields.paidRemaining > 0) updates.paidRemaining = fields.paidRemaining - 1;
      else throw new HttpsError('failed-precondition', 'Mesaj hakkın bitti. Bir paket seç.');
    }
    tx.create(msg, { uid, text, createdAt: new Date() });
    tx.update(ref, updates);
    tx.set(prefs, { hidden: false }, { merge: true });
    return status({ ...fields, ...updates, id: ref.id }, uid, balance.data());
  });
}

function cleanText(value) {
  const text = typeof value === 'string' ? value.trim() : '';
  if (!text || text.length > 1000) throw new HttpsError('invalid-argument', 'Mesaj 1–1000 karakter olmalı.');
  return text;
}
