import { HttpsError } from 'firebase-functions/v2/https';
import { eligible, eligibilityDocs, requireContact, tokens, validId, walletFor } from './account.js';
import { canJoinSession, quoteSession, spendSession } from './entitlements.js';

const rooms = new Set(['recovery', 'family', 'relationships', 'talk', 'work', 'general', 'loneliness']);
const duration = 15 * 60000;

export async function writtenAction(db, uid, data) {
  const { action, room, requestId, callId, messageId, text } = data;
  const queue = db.collection('writtenQueue');
  const mine = queue.doc(uid);
  if (['join', 'search', 'leave'].includes(action)) {
    if (!rooms.has(room) || !validId(requestId)) throw new HttpsError('invalid-argument', 'Geçersiz eşleşme isteği.');
    return db.runTransaction(async tx => {
      const now = Date.now();
      const [entry, balance] = await tx.getAll(mine, walletFor(db, uid));
      const row = entry.data();
      const same = row?.requestId === requestId;
      const wallet = balance.data();
      const quote = quoteSession(wallet, now);
      if (row?.callId && row.until > now && (same || action === 'join')) return { callId: row.callId };
      if (action === 'leave') {
        if (same && !row.callId) tx.delete(mine);
        return { waiting: false };
      }
      if (action === 'search' && (!same || !row.deadline || row.deadline <= now)) return { waiting: false };
      if (!canJoinSession(wallet, now)) return { waiting: false, funds: true, price: quote.cost, tokens: tokens(wallet) };
      const waiting = await tx.get(queue.where('room', '==', room).where('waitUntil', '>', now).orderBy('waitUntil').limit(12));
      for (const candidate of waiting.docs) {
        const other = candidate.id;
        if (other === uid) continue;
        const [theirWallet, mineBlock, theirBlock, ...theirStatus] = await tx.getAll(walletFor(db, other),
          db.doc('users/' + uid + '/blocks/' + other), db.doc('users/' + other + '/blocks/' + uid),
          ...eligibilityDocs(db, other));
        if (mineBlock.exists || theirBlock.exists || !eligible(theirStatus) || !canJoinSession(theirWallet.data(), now)) continue;
        const call = db.collection('writtenCalls').doc();
        const startBy = now + 90000;
        tx.create(call, { members: [uid, other], room, startBy, ready: [] });
        for (const [ref, id] of [[mine, requestId], [candidate.ref, candidate.get('requestId')]]) {
          tx.set(ref, { room, callId: call.id, requestId: id, until: startBy });
        }
        return { callId: call.id };
      }
      const deadline = same && row.deadline ? row.deadline : now + 90000;
      if (deadline <= now) return { waiting: false };
      tx.set(mine, { room, requestId, deadline, waitUntil: Math.min(now + 25000, deadline) });
      return { waiting: true, price: quote.cost };
    });
  }
  if (!validId(callId)) throw new HttpsError('invalid-argument', 'Geçersiz yazılı görüşme.');
  const ref = db.doc('writtenCalls/' + callId);
  const result = await db.runTransaction(async tx => {
    const now = Date.now();
    const call = (await tx.get(ref)).data();
    if (!call?.members?.includes(uid)) throw new HttpsError('permission-denied', 'Görüşmeye erişilemiyor.');
    const other = call.members.find(member => member !== uid);
    const current = { other, now, startBy: call.startBy, endsAt: call.endsAt || 0 };
    if (call.closed || now >= (call.endsAt || call.startBy)) return { ...current, closed: true };
    if (action === 'end') {
      const entries = await tx.getAll(...call.members.map(member => queue.doc(member)));
      tx.update(ref, { closed: true });
      entries.filter(entry => entry.get('callId') === callId).forEach(entry => tx.delete(entry.ref));
      return { ...current, closed: true };
    }
    await requireContact(db, tx, uid, other);
    if (action === 'read') return current;
    if (action === 'open') {
      if (call.endsAt || call.ready.includes(uid)) return current;
      const ready = [...call.ready, uid];
      if (ready.length < 2) {
        tx.update(ref, { ready });
        return current;
      }
      const wallets = await tx.getAll(...call.members.map(member => walletFor(db, member)));
      if (wallets.some(wallet => !canJoinSession(wallet.data(), now))) {
        throw new HttpsError('failed-precondition', 'Görüşme için yeterli jeton bulunamadı.');
      }
      const entries = await tx.getAll(...call.members.map(member => queue.doc(member)));
      call.members.forEach((member, index) => spendSession(db, tx, member, wallets[index].data(), 'written_' + callId, now));
      const endsAt = now + duration;
      tx.update(ref, { ready, endsAt });
      entries.filter(entry => entry.get('callId') === callId).forEach(entry => tx.update(entry.ref, { until: endsAt }));
      return { ...current, endsAt };
    }
    if (action === 'send') {
      if (!call.endsAt) throw new HttpsError('failed-precondition', 'Görüşme henüz başlamadı.');
      const body = typeof text === 'string' ? text.trim() : '';
      if (!validId(messageId) || !body || body.length > 1000) throw new HttpsError('invalid-argument', 'Mesaj 1–1000 karakter olmalı.');
      const message = ref.collection('messages').doc(messageId);
      if ((await tx.get(message)).exists) return current;
      const last = call.lastMessageAt?.[uid] || 0;
      if (now - last < 500) throw new HttpsError('resource-exhausted', 'Biraz bekleyip tekrar gönder.');
      tx.create(message, { uid, text: body, ts: now });
      tx.update(ref, { lastMessageAt: { ...call.lastMessageAt, [uid]: now } });
      return current;
    }
    throw new HttpsError('invalid-argument', 'Geçersiz işlem.');
  });
  if (action !== 'read' || !result.endsAt || result.closed) return result;
  const rows = await ref.collection('messages').orderBy('ts', 'desc').limit(60).get();
  return { ...result, messages: rows.docs.reverse().map(doc => ({ id: doc.id, ...doc.data() })) };
}
