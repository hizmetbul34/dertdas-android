import { HttpsError } from 'firebase-functions/v2/https';

export const walletFor = (db, uid) => db.doc('roomWallets/' + uid);
export const tokens = wallet => Math.max(0, Number.isSafeInteger(wallet?.tokens) ? wallet.tokens : 0);
export const validId = id => typeof id === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(id);

export const eligibilityDocs = (db, uid) => [
  db.doc('consents/' + uid), db.doc('suspensions/' + uid), db.doc('deletionRequests/' + uid)
];
export const eligible = ([consent, suspended, deletion]) =>
  consent.get('version') === '2026-11' && !suspended.exists && !deletion.exists;

export async function requireActive(db, uid) {
  if (!eligible(await db.getAll(...eligibilityDocs(db, uid)))) {
    throw new HttpsError('permission-denied', 'Hesabın bu işleme uygun değil.');
  }
}

export async function requireContact(db, tx, uid, other) {
  if (!validId(other) || uid === other) throw new HttpsError('invalid-argument', 'Kullanıcı geçersiz.');
  const [mine, theirs, ...status] = await tx.getAll(
    db.doc('users/' + uid + '/blocks/' + other),
    db.doc('users/' + other + '/blocks/' + uid), ...eligibilityDocs(db, other)
  );
  if (mine.exists || theirs.exists || !eligible(status)) {
    throw new HttpsError('failed-precondition', 'Bu kullanıcıyla iletişim kurulamıyor.');
  }
}

export function changeTokens(tx, db, uid, wallet, amount, reason, id) {
  const next = (Number.isSafeInteger(wallet?.tokens) ? wallet.tokens : 0) + amount;
  if (amount < 0 && next < 0) throw new HttpsError('failed-precondition', 'Jeton bakiyen yetersiz.');
  const ref = walletFor(db, uid);
  tx.set(ref, { tokens: next }, { merge: true });
  tx.create(ref.collection('ledger').doc(id), { amount, reason, createdAt: new Date() });
  return Math.max(0, next);
}
