import { Timestamp } from 'firebase-admin/firestore';

const boostCategories = new Set(['Aşk ve İlişkiler', 'Okul ve İş']);
const boostDurationMs = 24 * 60 * 60 * 1000;
const boostLimit = 8;
const guides = new Map([
  ['family', [
    'Bugün çözmek istediğin tek konuyu ve konuşmak için sakin bir zamanı seç.',
    'Yaşadığın olayı ve sende bıraktığı hissi söyle. “Bu konu açıldığında geriliyorum ve önce beni dinlemene ihtiyacım var.”',
    'Bir istekte bulun. Konuşma gerilirse “Biraz ara verip bu akşam tekrar konuşabilir miyiz?” diyebilirsin.'
  ]],
  ['relationships', [
    'Bu konuşmanın sonunda neyin netleşmesini istiyorum?',
    'Beni rahatsız eden olay neydi? Karşımdaki kişinin yorumunu hangi açık soruyla öğrenebilirim?',
    'Bugün ikimizin de yapabileceği en küçük değişiklik ne?'
  ]],
  ['work', [
    'İlanı aç ve en önemli üç beklentiyi yaz. Her biri için geçmişinden bir örnek seç.',
    'Örnekleri durum, sorumluluğun, yaptığın iş ve sonuç sırasıyla anlatmayı prova et.',
    'Ekipte ilk 90 günde nelerin beklendiğini ve başarının nasıl değerlendirildiğini sor.'
  ]],
  ['talk', [
    'Bugün aklına en çok takılan şeyi bir cümleyle yaz.',
    'Gördüğün olayı ve bu olay hakkında aklından geçenleri ayrı ayrı yaz.',
    'Şu an neye ihtiyacın olduğunu ve yarın yapabileceğin küçük bir şeyi seç.'
  ]]
]);

export async function readVipGuide(db, uid, room, HttpsError) {
  const steps = guides.get(room);
  if (!steps) throw new HttpsError('invalid-argument', 'Bu odada VIP rehberi bulunmuyor.');
  const [wallet, consent, suspension, deletion] = await db.getAll(db.doc('roomWallets/' + uid),
    db.doc('consents/' + uid), db.doc('suspensions/' + uid), db.doc('deletionRequests/' + uid));
  if (consent.get('version') !== '2026-11' || suspension.exists || deletion.exists) {
    throw new HttpsError('permission-denied', 'Bu hesap rehberi açamıyor.');
  }
  const expiry = wallet.get('vipUntil');
  const now = Date.now();
  return ((expiry instanceof Timestamp && expiry.toMillis() > now) || (wallet.get('unlimitedUntil') || 0) > now || (wallet.get('vipUntilMs') || 0) > now)
    ? { active: true, steps }
    : { active: false };
}

export async function boostPost(db, uid, postId, HttpsError) {
  if (typeof postId !== 'string' || !/^[a-z0-9]{20}$/i.test(postId)) {
    throw new HttpsError('invalid-argument', 'Geçersiz gönderi.');
  }

  const postRef = db.doc('posts/' + postId);
  const walletRef = db.doc('roomWallets/' + uid);
  return db.runTransaction(async tx => {
    const [post, wallet, consent, suspension, deletion] = await tx.getAll(postRef, walletRef,
      db.doc('consents/' + uid), db.doc('suspensions/' + uid), db.doc('deletionRequests/' + uid));
    if (post.get('uid') !== uid || consent.get('version') !== '2026-11' || suspension.exists || deletion.exists) {
      throw new HttpsError('permission-denied', 'Bu gönderiyi öne çıkaramazsın.');
    }
    const category = post.get('category');
    if (!boostCategories.has(category)) {
      throw new HttpsError('failed-precondition', 'Bu odada gönderi öne çıkarma yok.');
    }

    const now = Timestamp.now();
    if (post.get('boostedUntil')?.toMillis() > now.toMillis()) return { active: true };
    const tokens = wallet.get('tokens');
    if (!Number.isSafeInteger(tokens) || tokens < 1) {
      throw new HttpsError('failed-precondition', 'Öne çıkarmak için 1 jeton gerekiyor.');
    }
    const activeBoosts = await tx.get(db.collection('posts').where('category', '==', category)
      .where('boostedUntil', '>', now).orderBy('boostedUntil', 'desc').limit(boostLimit));
    if (activeBoosts.size >= boostLimit) {
      throw new HttpsError('failed-precondition', 'Öne çıkarma alanı dolu. Biraz sonra tekrar dene.');
    }

    tx.update(postRef, { boostedUntil: Timestamp.fromMillis(now.toMillis() + boostDurationMs) });
    tx.update(walletRef, { tokens: tokens - 1 });
    return { active: true };
  });
}
