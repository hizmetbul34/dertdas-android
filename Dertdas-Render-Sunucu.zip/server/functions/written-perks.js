import { HttpsError } from 'firebase-functions/v2/https';
import { changeTokens, tokens, validId, walletFor } from './account.js';

export const duration = 15 * 60000;
const extension = { minutes: 5, cost: 5, max: 3 };
const gifts = [
  { id: 'spark', label: 'Kıvılcım', symbol: '✦', cost: 1 },
  { id: 'tea', label: 'Çay', symbol: '☕', cost: 3 },
  { id: 'flower', label: 'Çiçek', symbol: '🌼', cost: 5 }
];
const favorites = (db, uid) => db.collection('users/' + uid + '/writtenFavorites');

export async function manageWrittenFavorites(db, uid, data) {
  const collection = favorites(db, uid);
  if (data.action === 'favorites') {
    const rows = await collection.orderBy('addedAt', 'desc').limit(50).get();
    return { favorites: rows.docs.map(doc => ({ id: doc.id, name: doc.get('name'), room: doc.get('room') })) };
  }
  if (!validId(data.other)) throw new HttpsError('invalid-argument', 'Favori bulunamadı.');
  await collection.doc(data.other).delete();
  return { favorite: false };
}

export function writtenChatTools(call, now) {
  const offer = call.extensionOffer;
  return {
    gifts,
    extension: {
      minutes: extension.minutes, cost: extension.cost,
      remaining: Math.max(0, extension.max - (call.extensionCount || 0)),
      offer: offer?.expiresAt > now ? { id: offer.id, from: offer.from } : null
    }
  };
}

export async function writtenIdentity(db, tx, uid, other) {
  const [profile, favorite] = await tx.getAll(db.doc('users/' + other), favorites(db, uid).doc(other));
  const handle = profile.get('handle');
  return { name: typeof handle === 'string' && /^[a-z0-9_]{3,30}$/i.test(handle) ? '@' + handle : 'Sohbet arkadaşı', favorite: favorite.exists };
}

export async function applyWrittenPerk(db, tx, { uid, other, callId, ref, call, current, data, queue }) {
  if (!call.endsAt) throw new HttpsError('failed-precondition', 'Görüşme henüz başlamadı.');
  const { action, requestId } = data;
  const now = current.now;
  if (action === 'favorite') {
    const favorite = favorites(db, uid).doc(other);
    if (data.enabled === false) {
      tx.delete(favorite);
      return { favorite: false };
    }
    if (data.enabled !== true) throw new HttpsError('invalid-argument', 'Favori seçimi geçersiz.');
    const { name } = await writtenIdentity(db, tx, uid, other);
    tx.set(favorite, { name, room: call.room, addedAt: new Date(now) });
    return { favorite: true };
  }

  if (!validId(requestId)) throw new HttpsError('invalid-argument', 'İşlem kimliği geçersiz.');
  const message = ref.collection('messages').doc(action === 'gift' ? 'gift_' + uid + '_' + requestId : 'extend_' + requestId);
  if (action === 'gift') {
    const gift = gifts.find(item => item.id === data.gift);
    if (!gift) throw new HttpsError('invalid-argument', 'Hediye bulunamadı.');
    const [existing, wallet] = await tx.getAll(message, walletFor(db, uid));
    if (existing.exists) return current;
    changeTokens(tx, db, uid, wallet.data(), -gift.cost, 'Sohbet hediyesi: ' + gift.label, 'gift_' + callId + '_' + requestId);
    tx.create(message, { uid, kind: 'gift', gift: gift.id, text: gift.label, ts: now });
    return current;
  }

  if (action === 'extendOffer') {
    if ((call.extensionCount || 0) >= extension.max) throw new HttpsError('failed-precondition', 'Bu sohbet uzatma sınırına ulaştı.');
    if (current.chatTools.extension.offer) {
      if (call.extensionOffer.id === requestId && call.extensionOffer.from === uid) return current;
      throw new HttpsError('failed-precondition', 'Yanıt bekleyen bir süre uzatma teklifi var.');
    }
    const wallet = await tx.get(walletFor(db, uid));
    if (tokens(wallet.data()) < extension.cost) throw new HttpsError('failed-precondition', 'Süreyi uzatmak için 5 jeton gerekiyor.');
    const extensionOffer = { id: requestId, from: uid, expiresAt: Math.min(call.endsAt, now + 45000) };
    tx.update(ref, { extensionOffer });
    return { ...current, chatTools: writtenChatTools({ ...call, extensionOffer }, now) };
  }

  const existing = await tx.get(message);
  if (existing.exists) return current;
  const offer = current.chatTools.extension.offer;
  if (offer?.id !== requestId || offer.from !== other) throw new HttpsError('failed-precondition', 'Uzatma teklifi sona erdi.');
  if (action === 'extendDecline') {
    tx.update(ref, { extensionOffer: null });
    return { ...current, chatTools: writtenChatTools({ ...call, extensionOffer: null }, now) };
  }
  const [wallet, ...queueEntries] = await tx.getAll(walletFor(db, other), ...call.members.map(member => queue.doc(member)));
  const endsAt = call.endsAt + extension.minutes * 60000;
  const extensionCount = (call.extensionCount || 0) + 1;
  changeTokens(tx, db, other, wallet.data(), -extension.cost, 'Yazılı sohbet uzatma', 'extend_' + callId + '_' + requestId);
  tx.update(ref, { endsAt, extensionCount, extensionOffer: null });
  queueEntries.filter(entry => entry.get('callId') === callId).forEach(entry => tx.update(entry.ref, { until: endsAt }));
  tx.create(message, { uid: other, kind: 'extension', text: 'Sohbet 5 dakika uzatıldı.', ts: now });
  return { ...current, endsAt, chatTools: writtenChatTools({ ...call, extensionCount, extensionOffer: null }, now) };
}
