import { createServer } from 'node:http';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import app from './dist/render-handler.mjs';

const env = {
  ...process.env,
  FIREBASE_PROJECT_ID: process.env.FIREBASE_PROJECT_ID || 'dertdasv2',
};
const localOrigin = 'http://localhost';
const port = Number(process.env.PORT || 10000);

const server = createServer(async (incoming, outgoing) => {
  try {
    const headers = new Headers(incoming.headers);
    const method = incoming.method;
    const url = new URL(incoming.url, localOrigin);
    if (url.origin !== localOrigin) {
      outgoing.writeHead(400).end();
      return;
    }

    const init = { method, headers };
    if (method !== 'GET' && method !== 'HEAD') {
      init.body = Readable.toWeb(incoming);
      init.duplex = 'half';
    }

    const response = await app.fetch(new Request(url, init), env);
    outgoing.writeHead(response.status, Object.fromEntries(response.headers));
    if (response.body) await pipeline(Readable.fromWeb(response.body), outgoing);
    else outgoing.end();
  } catch {
    if (outgoing.headersSent) outgoing.destroy();
    else outgoing.writeHead(500).end();
  }
});

server.listen(port, '0.0.0.0');
