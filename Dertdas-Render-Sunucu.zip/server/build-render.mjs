import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';

const entry = path => fileURLToPath(new URL(path, import.meta.url));

await build({
  entryPoints: [entry('./worker/index.js')],
  outfile: entry('./dist/render-handler.mjs'),
  bundle: true,
  platform: 'node',
  format: 'esm',
  target: 'node22',
  alias: {
    'firebase-functions/v2/https': entry('./worker/https.js'),
    'firebase-admin/firestore': entry('./worker/firestore.js'),
  },
});
