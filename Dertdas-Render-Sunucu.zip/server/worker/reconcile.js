import { createHash } from 'node:crypto';

const sixHours = 6 * 3600000;
const digest = value => createHash('sha256').update(value).digest('hex');

function base64(bytes) {
  return btoa(String.fromCharCode(...new Uint8Array(bytes)));
}
function bytes(value) {
  return Uint8Array.from(atob(value), ch => ch.charCodeAt(0));
}

async function receiptKey(secret) {
  const key = bytes(secret);
  if (key.length !== 32) throw new Error('Makbuz anahtarı 32 bayt olmalı.');
  return crypto.subtle.importKey('raw', key, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}

export async function rememberSubscription(db, env, uid, product, token) {
  const ref = db.doc('playReceipts/' + digest(token));
  const receipt = await ref.get();
  if (!receipt.exists || receipt.get('uid') !== uid || receipt.get('product') !== product) return;
  const key = await receiptKey(env.PURCHASE_RECEIPT_KEY);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(receipt.id) },
    key, new TextEncoder().encode(token));
  await db.doc('workerSubscriptionChecks/' + receipt.id).set({
    uid, product, nextCheck: Date.now() + sixHours, iv: base64(iv), ciphertext: base64(encrypted)
  });
}

export async function reconcile(db, env, billing, publisher) {
  const key = await receiptKey(env.PURCHASE_RECEIPT_KEY);
  const due = await db.collection('workerSubscriptionChecks').where('nextCheck', '<=', Date.now()).orderBy('nextCheck').limit(2).get();
  let failures = 0;
  for (const row of due.docs) {
    try {
      const { uid, product, iv, ciphertext } = row.data();
      if (!(await db.doc('playReceipts/' + row.id).get()).exists ||
          (await db.doc('deletionRequests/' + uid).get()).exists) {
        await row.ref.delete();
        continue;
      }
      const token = new TextDecoder().decode(await crypto.subtle.decrypt({
        name: 'AES-GCM', iv: bytes(iv), additionalData: new TextEncoder().encode(row.id)
      }, key, bytes(ciphertext)));
      const snapshot = await billing.purchase(db, uid, { product, purchaseToken: token });
      if (!snapshot.vipPlan && snapshot.unlimitedUntil <= Date.now()) {
        // A canceled, expired entitlement needs no frequent lookup, but retries still catch recovery.
        await row.ref.set({ nextCheck: Date.now() + 7 * 24 * 3600000 }, { merge: true });
      } else await row.ref.set({ nextCheck: Date.now() + sixHours }, { merge: true });
    } catch {
      failures++;
      await row.ref.set({ nextCheck: Date.now() + 3600000 }, { merge: true }).catch(() => {});
    }
  }

  // Save the cursor only after processing the page. A replay uses the existing refund journal.
  const pointer = db.doc('workerMaintenance/voidedPurchases');
  const state = await pointer.get();
  const endTime = state.get('pageEnd') || Date.now();
  const startTime = Math.max(state.get('startTime') || endTime - 24 * 3600000, endTime - 29 * 24 * 3600000);
  const opts = new URLSearchParams({ type: '0', maxResults: '2', startTime: String(startTime), endTime: String(endTime) });
  if (state.get('pageToken')) opts.set('token', state.get('pageToken'));
  const report = await publisher('purchases/voidedpurchases?' + opts);
  for (const row of report.voidedPurchases || []) {
    if (!row.purchaseToken) continue;
    await billing.playNotification(db, { packageName:'com.dertdas.app',
      voidedPurchaseNotification: { purchaseToken: row.purchaseToken, refundType: 1 } });
  }
  const pageToken = report.tokenPagination?.nextPageToken || '';
  await pointer.set({ startTime: pageToken ? startTime : endTime - 120000,
    pageEnd: pageToken ? endTime : 0, pageToken });
  if (failures) console.warn('Dertdaş abonelik kontrolü yeniden denenecek.');
}
