import { firestore } from './firestore.js';
import { HttpsError } from './https.js';
import { playPublisher, verifyFirebaseUser } from './google.js';
import { createBilling } from '../functions/billing-core.js';
import { requireActive } from '../functions/account.js';
import { messageAction } from '../functions/messages.js';
import { writtenAction } from '../functions/written.js';
import { processMatch } from '../functions/match.js';
import { voiceAction } from '../functions/voice.js';
import { boostPost, readVipGuide } from '../functions/room-perks.js';
import { reconcile, rememberSubscription } from './reconcile.js';

const origin = 'https://appassets.androidplatform.net';
const httpCodes = { 'unauthenticated': 401, 'permission-denied': 403, 'invalid-argument': 400,
  'failed-precondition': 400, 'already-exists': 409, 'not-found': 404, 'resource-exhausted': 429 };

function response(req, body, status = 200) {
  const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
  if (req.headers.get('Origin') === origin) headers['Access-Control-Allow-Origin'] = origin;
  return new Response(body ? JSON.stringify(body) : null, { status, headers });
}

async function route(request, env) {
  const url = new URL(request.url);
  if (url.pathname === '/health' && request.method === 'GET') return response(request, { service: 'dertdas', version: 20 });
  if (url.pathname !== '/roomMatch') return response(request, null, 404);
  const caller = request.headers.get('Origin');
  if (caller && caller !== origin) return response(request, null, 403);
  if (request.method === 'OPTIONS' && caller === origin) {
    return new Response(null, { status: 204, headers: { 'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Authorization, Content-Type',
      'Access-Control-Max-Age': '600' } });
  }
  if (request.method !== 'POST') return response(request, null, 405);
  const uid = await verifyFirebaseUser(request, env.FIREBASE_PROJECT_ID);
  let body;
  try {
    const reader = request.body?.getReader();
    const decoder = new TextDecoder();
    let raw = '';
    let size = 0;
    while (reader) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 65000) {
        await reader.cancel();
        throw new Error('Payload too large.');
      }
      raw += decoder.decode(value, { stream: true });
    }
    body = JSON.parse(raw + decoder.decode()).data;
  } catch {
    throw new HttpsError('invalid-argument', 'İstek geçersiz.');
  }
  if (!body || typeof body.action !== 'string') throw new HttpsError('invalid-argument', 'İşlem geçersiz.');
  const db = firestore(env.FIREBASE_PROJECT_ID, env.FIRESTORE_SERVICE_ACCOUNT_JSON);
  await requireActive(db, uid);
  const readyVoice = Boolean(env.VOICE_TURN_URL && env.VOICE_TURN_SECRET);
  if (['join', 'priorityJoin', 'status', 'claim', 'voice'].includes(body.action) && body.protocolVersion !== 16) {
    throw new HttpsError('failed-precondition', 'Dertdaş’ın güncel sürümünü kullan.');
  }
  let result;
  if (body.action === 'wallet') {
    result = await createBilling(async () => { throw new Error('Play API çağrısı beklenmiyordu.'); }).walletStatus(db, uid);
  } else if (body.action === 'checkout' || body.action === 'purchase') {
    const publisher = playPublisher(env.PLAY_SERVICE_ACCOUNT_JSON);
    const billing = createBilling(publisher);
    if (body.action === 'checkout') {
      if (String(body.product).startsWith('vip_') && (!readyVoice || !env.PURCHASE_RECEIPT_KEY)) result = { state: 'voice_setup' };
      else result = await billing.authorizeCheckout(db, uid, body.product);
    } else {
      result = await billing.purchase(db, uid, body.data || {});
      const { product, purchaseToken } = body.data || {};
      if (typeof product === 'string' && (product.startsWith('vip_') || product === 'sinirsiz_mesaj')) {
        await rememberSubscription(db, env, uid, product, purchaseToken);
      }
    }
  } else if (body.action === 'written') result = await writtenAction(db, uid, body.data || {});
  else if (body.action === 'message') result = await messageAction(db, uid, body.data || {});
  else if (body.action === 'voice') result = await voiceAction(db, uid, body.data || {}, env);
  else if (body.action === 'boost') result = await boostPost(db, uid, body.postId, HttpsError);
  else if (body.action === 'vipGuide') result = await readVipGuide(db, uid, body.room, HttpsError);
  else if (body.action === 'adultStatus') {
    result = { confirmed: (await db.doc('adultConfirmations/' + uid).get()).get('confirmed') === true };
  } else if (body.action === 'adultConfirm') {
    if (body.confirmed !== true) throw new HttpsError('invalid-argument', 'Yaş onayı gerekiyor.');
    await db.doc('adultConfirmations/' + uid).set({ confirmed: true });
    result = { confirmed: true };
  } else if (body.action === 'available' && !readyVoice) result = { voiceReady: false, listeners: 0 };
  else {
    const data = body.action === 'priorityJoin' ? { ...body, action: 'join', priority: false } : body;
    if (data.action === 'join' && !readyVoice) throw new HttpsError('failed-precondition', 'Sesli görüşme sunucusu henüz hazır değil.');
    result = await processMatch(db, uid, data, HttpsError);
    if (data.action === 'available') result.voiceReady = readyVoice && data.protocolVersion === 16;
  }
  return response(request, { result });
}

export default {
  async fetch(request, env) {
    try {
      return await route(request, env);
    } catch (error) {
      const known = error instanceof HttpsError;
      const code = known ? error.code : 'internal';
      if (!known) console.warn('Dertdaş sunucu işlemi tamamlanamadı.');
      return response(request, { error: { status: code.replaceAll('-', '_').toUpperCase(),
        message: known ? error.message : 'Sunucu işlemi tamamlanamadı.' } }, httpCodes[code] || 500);
    }
  },
  async scheduled(_event, env) {
    if (!env.FIRESTORE_SERVICE_ACCOUNT_JSON || !env.PLAY_SERVICE_ACCOUNT_JSON || !env.PURCHASE_RECEIPT_KEY) return;
    const db = firestore(env.FIREBASE_PROJECT_ID, env.FIRESTORE_SERVICE_ACCOUNT_JSON);
    const publisher = playPublisher(env.PLAY_SERVICE_ACCOUNT_JSON);
    await reconcile(db, env, createBilling(publisher), publisher);
  }
};
