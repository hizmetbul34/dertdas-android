import { googleAccess } from './google.js';

export class Timestamp extends Date {
  static now() { return new Timestamp(); }
  static fromMillis(value) { return new Timestamp(value); }
  toMillis() { return this.getTime(); }
}

function encode(value) {
  if (value === null) return { nullValue: null };
  if (value instanceof Date) return { timestampValue: value.toISOString() };
  if (Array.isArray(value)) return { arrayValue: { values: value.map(encode) } };
  if (typeof value === 'object') return { mapValue: { fields: encodeFields(value) } };
  switch (typeof value) {
    case 'string': return { stringValue: value };
    case 'boolean': return { booleanValue: value };
    case 'number':
      if (!Number.isFinite(value)) throw new Error('Geçersiz Firestore sayısı.');
      return Number.isSafeInteger(value) ? { integerValue: String(value) } : { doubleValue: value };
    default: throw new Error('Geçersiz Firestore değeri.');
  }
}

function encodeFields(fields) {
  return Object.fromEntries(Object.entries(fields).filter(([, value]) => value !== undefined).map(([key, value]) => [key, encode(value)]));
}

function decode(field) {
  if ('nullValue' in field) return null;
  if ('timestampValue' in field) return new Timestamp(field.timestampValue);
  if ('integerValue' in field) return Number(field.integerValue);
  if ('arrayValue' in field) return (field.arrayValue.values || []).map(decode);
  if ('mapValue' in field) return decodeFields(field.mapValue.fields);
  return field.stringValue ?? field.booleanValue ?? field.doubleValue;
}

function decodeFields(fields = {}) {
  return Object.fromEntries(Object.entries(fields).map(([key, value]) => [key, decode(value)]));
}

class Snapshot {
  constructor(ref, doc) {
    this.ref = ref;
    this.id = ref.id;
    this.exists = Boolean(doc);
    this.fields = doc ? decodeFields(doc.fields) : undefined;
  }
  data() { return this.fields; }
  get(key) { return this.fields?.[key]; }
}

class Document {
  constructor(db, path) {
    this.db = db;
    this.path = path;
    this.id = path.split('/').at(-1);
    this.name = db.documentRoot + '/' + path;
  }
  get() { return this.db.read([this]).then(([doc]) => doc); }
  set(fields, options) { return this.db.runTransaction(tx => tx.set(this, fields, options)); }
  delete() { return this.db.runTransaction(tx => tx.delete(this)); }
  collection(name) { return this.db.collection(this.path + '/' + name); }
}

const operators = { '==': 'EQUAL', '>': 'GREATER_THAN', '>=': 'GREATER_THAN_OR_EQUAL',
  '<': 'LESS_THAN', '<=': 'LESS_THAN_OR_EQUAL', 'array-contains': 'ARRAY_CONTAINS' };

class Query {
  constructor(db, path, clauses = [], order = [], max = undefined) {
    Object.assign(this, { db, path, clauses, order, max });
  }
  doc(id = crypto.randomUUID().replaceAll('-', '')) { return this.db.doc(this.path + '/' + id); }
  where(fieldPath, op, value) {
    if (!operators[op]) throw new Error('Sorgu operatörü desteklenmiyor.');
    return new Query(this.db, this.path, [...this.clauses, { fieldFilter: { field: { fieldPath }, op: operators[op], value: encode(value) } }], this.order, this.max);
  }
  orderBy(fieldPath, direction = 'asc') {
    return new Query(this.db, this.path, this.clauses, [...this.order, { field: { fieldPath }, direction: direction === 'desc' ? 'DESCENDING' : 'ASCENDING' }], this.max);
  }
  limit(max) { return new Query(this.db, this.path, this.clauses, this.order, max); }
  get() { return this.db.query(this); }
}

class Transaction {
  constructor(db, id) {
    this.db = db;
    this.id = id;
    this.pending = new Map();
  }
  get(ref) { return ref instanceof Query ? this.db.query(ref, this.id) : this.getAll(ref).then(([doc]) => doc); }
  getAll(...refs) {
    if (this.pending.size) throw new Error('Firestore okumaları yazılardan önce yapılmalı.');
    return this.db.read(refs, this.id);
  }
  set(ref, data, opts) { this.write(ref, data, opts?.merge ? 'merge' : 'set'); }
  create(ref, data) { this.write(ref, data, 'create'); }
  update(ref, data) { this.write(ref, data, 'update'); }
  delete(ref) { this.pending.set(ref.name, { delete: ref.name }); }
  write(ref, data, kind) {
    const fields = encodeFields(data);
    const previous = this.pending.get(ref.name);
    if (previous?.update && kind === 'merge') {
      Object.assign(previous.update.fields, fields);
      if (previous.updateMask) previous.updateMask.fieldPaths = Object.keys(previous.update.fields);
      return;
    }
    const operation = { update: { name: ref.name, fields } };
    if (kind === 'merge' || kind === 'update') operation.updateMask = { fieldPaths: Object.keys(fields) };
    if (kind === 'create' || kind === 'update') operation.currentDocument = { exists: kind === 'update' };
    this.pending.set(ref.name, operation);
  }
}

export function firestore(project, secret) {
  const access = googleAccess(secret, 'https://www.googleapis.com/auth/datastore');
  const documentRoot = 'projects/' + project + '/databases/(default)/documents';
  async function rpc(path, body) {
    const response = await fetch('https://firestore.googleapis.com/v1/' + documentRoot + path, {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + await access(), 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(9000)
    });
    const data = await response.json();
    if (!response.ok) {
      const error = new Error('Firestore işlemi tamamlanamadı.');
      error.status = data.error?.status;
      throw error;
    }
    return data;
  }
  const db = {
    documentRoot,
    doc: path => new Document(db, path),
    collection: path => new Query(db, path),
    getAll: (...refs) => db.read(refs),
    async read(refs, transaction) {
      if (!refs.length) return [];
      const rows = await rpc(':batchGet', { documents: refs.map(ref => ref.name), transaction });
      const docs = new Map(rows.filter(row => row.found).map(row => [row.found.name, row.found]));
      return refs.map(ref => new Snapshot(ref, docs.get(ref.name)));
    },
    async query(query, transaction) {
      const segments = query.path.split('/');
      const collectionId = segments.pop();
      const where = query.clauses.length > 1
        ? { compositeFilter: { op: 'AND', filters: query.clauses } } : query.clauses[0];
      const parent = segments.length ? '/' + segments.map(encodeURIComponent).join('/') : '';
      const rows = await rpc(parent + ':runQuery', {
        transaction,
        structuredQuery: { from: [{ collectionId }], where, orderBy: query.order, limit: query.max }
      });
      const docs = rows.filter(row => row.document).map(({ document }) =>
        new Snapshot(db.doc(document.name.slice(documentRoot.length + 1)), document));
      return { docs, empty: !docs.length, size: docs.length };
    },
    async runTransaction(run) {
      for (let attempt = 0; attempt < 4; attempt++) {
        let id;
        try {
          ({ transaction: id } = await rpc(':beginTransaction', {}));
          const tx = new Transaction(db, id);
          const result = await run(tx);
          if (tx.pending.size) await rpc(':commit', { transaction: id, writes: [...tx.pending.values()] });
          else await rpc(':rollback', { transaction: id }).catch(() => {});
          return result;
        } catch (error) {
          if (id) await rpc(':rollback', { transaction: id }).catch(() => {});
          if (!['ABORTED', 'ALREADY_EXISTS'].includes(error.status) || attempt === 3) throw error;
          await new Promise(resolve => setTimeout(resolve, 30 * (2 ** attempt)));
        }
      }
    }
  };
  return db;
}
