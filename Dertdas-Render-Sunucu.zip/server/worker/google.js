import { createRemoteJWKSet, importPKCS8, jwtVerify, SignJWT } from 'jose';
import { HttpsError } from './https.js';

const googleKeys = createRemoteJWKSet(new URL(
  'https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com'
));
const tokenEndpoint = 'https://oauth2.googleapis.com/token';
const cachedCredentials = new Map();

export async function verifyFirebaseUser(request, project) {
  const authorization = request.headers.get('Authorization') || '';
  if (!/^Bearer [A-Za-z\d_-]+\.[A-Za-z\d_-]+\.[A-Za-z\d_-]+$/.test(authorization) || authorization.length > 10000) {
    throw new HttpsError('unauthenticated', 'Önce giriş yap.');
  }
  let payload;
  try {
    ({ payload } = await jwtVerify(authorization.slice(7), googleKeys, {
      issuer: 'https://securetoken.google.com/' + project,
      audience: project, algorithms: ['RS256'],
      requiredClaims: ['exp', 'iat', 'sub', 'auth_time']
    }));
  } catch {
    throw new HttpsError('unauthenticated', 'Oturum doğrulanamadı. Tekrar giriş yap.');
  }
  const now = Math.floor(Date.now() / 1000);
  if (!/^[A-Za-z0-9_-]{1,128}$/.test(payload.sub) || payload.iat > now ||
      typeof payload.auth_time !== 'number' || payload.auth_time > now ||
      payload.email_verified !== true || payload.firebase?.sign_in_provider !== 'password') {
    throw new HttpsError('permission-denied', 'Doğrulanmış e-posta ile giriş yap.');
  }
  return payload.sub;
}

async function mintToken(account, scope) {
  const privateKey = await importPKCS8(account.private_key, 'RS256');
  const assertion = await new SignJWT({ scope })
    .setProtectedHeader({ alg: 'RS256', kid: account.private_key_id })
    .setIssuer(account.client_email).setAudience(tokenEndpoint)
    .setIssuedAt().setExpirationTime('55m').sign(privateKey);
  const response = await fetch(tokenEndpoint, {
    method: 'POST',
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion
    }),
    signal: AbortSignal.timeout(7000)
  });
  if (!response.ok) throw new Error('Google hizmet hesabı doğrulanamadı.');
  const data = await response.json();
  return { token: data.access_token, expires: Date.now() + (Number(data.expires_in) - 60) * 1000 };
}

export function googleAccess(secret, scope) {
  if (!secret) throw new HttpsError('failed-precondition', 'Sunucu yetkisi henüz yapılandırılmadı.');
  const account = JSON.parse(secret);
  if (account.type !== 'service_account' || !account.client_email || !account.private_key || !account.private_key_id) {
    throw new HttpsError('failed-precondition', 'Sunucunun Google hizmet hesabı eksik.');
  }
  const key = account.client_email + '/' + account.private_key_id + '/' + scope;
  return async () => {
    let entry = cachedCredentials.get(key);
    if (!entry || (!entry.pending && entry.expires <= Date.now())) {
      const pending = mintToken(account, scope).then(result => {
        cachedCredentials.set(key, result);
        return result;
      }).catch(error => {
        cachedCredentials.delete(key);
        throw error;
      });
      entry = { pending };
      cachedCredentials.set(key, entry);
    }
    return entry.pending ? (await entry.pending).token : entry.token;
  };
}

export function playPublisher(secret) {
  const access = googleAccess(secret, 'https://www.googleapis.com/auth/androidpublisher');
  return async (path, method = 'GET') => {
    const response = await fetch(
      'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/com.dertdas.app/' + path,
      { method, headers: { Authorization: 'Bearer ' + await access() }, signal: AbortSignal.timeout(7000) }
    );
    if (!response.ok) {
      const error = new Error('Google Play işlemi tamamlanamadı.');
      error.response = { status: response.status };
      throw error;
    }
    const payload = await response.text();
    return payload ? JSON.parse(payload) : {};
  };
}
