# Dertdaş Android başlangıç projesi

Bu paket telefonla düzenlenebilen bir Android WebView uygulama kabuğu ve başlangıç arayüzü içerir. İlk sürümde paylaşım akışı ve profil adı cihaz üzerinde demo olarak çalışır. Gerçek hesap, çevrimiçi paylaşım, yorum/like, özel mesaj, moderasyon, reklam ve ödeme henüz backend kurulumu gerektirir; bu demoyu gerçek sosyal ağ veya ödeme sistemi olarak yayımlamayın.

## Android build (GitHub Actions)
1. ZIP'i çıkarıp GitHub'da yeni repo açın ve proje dosyalarını yükleyin.
2. `.github/workflows/android.yml` workflow'u Actions ile build başlatır.
3. Çıkan AAB dosyası Play Console için imzalama yapılandırması ve test gerektirir. Play Console'a kullanıcı hesabınızla giriş, kayıt/ücret, kimlik doğrulama, uygulama imzası ve gönderme işlemleri kullanıcı tarafından yapılır.

## Firebase
Firebase Console'da Android uygulaması `com.dertdas.app` kimliğiyle kaydedilmelidir. Auth (email/password), Firestore, güvenlik kuralları ve spam/moderasyon kuralları yapılandırılmadan gerçek kullanıcı verisi tutmayın. Bu demo Firebase'e bağlanmıyor.

## Play mağaza taslak metni
**Ad:** Dertdaş – Sohbet ve Topluluk  
**Kısa açıklama:** Düşüncelerini paylaş, topluluklarda sohbet et ve birbirini dinle.  
**Uzun açıklama:** Dertdaş; insanların düşüncelerini paylaşmayı, farklı topluluklarda sohbet etmeyi ve birbirini dinlemeyi amaçlayan sosyal bir platform fikridir. Uygulama geliştirme aşamasındadır.  

Yayın öncesinde gerçek uygulama özelliklerine uygun gizlilik politikası, içerik bildirme ve engelleme, moderasyon, veri güvenliği, yaş derecelendirmesi, mağaza ekran görüntüleri ve Play Console test koşulları hazırlanmalıdır.
