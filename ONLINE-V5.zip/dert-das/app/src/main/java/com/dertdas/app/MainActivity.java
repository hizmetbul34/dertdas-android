package com.dertdas.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    WebView w = new WebView(this);
    w.setBackgroundColor(0xff10111a);
    WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false); s.setAllowContentAccess(false);
    w.setWebViewClient(new android.webkit.WebViewClient(){ @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request){ if(request.getUrl().toString().equals("https://appassets.androidplatform.net/index.html")){try{return new android.webkit.WebResourceResponse("text/html","UTF-8",getAssets().open("index.html"));}catch(java.io.IOException e){return null;}} return null; }}); w.loadUrl("https://appassets.androidplatform.net/index.html"); setContentView(w);
    getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    if(android.os.Build.VERSION.SDK_INT>=30){w.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets i=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.ime());v.setPadding(i.left,i.top,i.right,i.bottom);return insets;});w.requestApplyInsets();}
  }
}
