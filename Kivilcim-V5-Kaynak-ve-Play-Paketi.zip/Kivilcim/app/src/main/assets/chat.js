'use strict';
let roomState = null;
let renderedRoom = '';
let chatBusy = false;
let chatAccount = null;
let getStatePending = false;
let lastPoll = 0;
let lastLoad = 0;
let chatError = '';
const delivered = new Set();
const tokenPacks = [[25,50],[50,100],[75,150],[100,200]];
const timePacks = [[15,25],[30,50]];
let playPrices = {};
const nativePlay = navigator.userAgent.includes('KivilcimAndroid/2');
const timestamp = () => Math.floor(Date.now()/1000);
const istanbulDay = new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'});

function demoChat(action, data) {
  const key = 'kivilcim.demo.chat.v2';
  let value;
  try {value=JSON.parse(localStorage.getItem(key));} catch {}
  if(!value) value={status:'idle',balance:100};
  const now=timestamp();
  const day=istanbulDay.format(new Date(now*1000));
  if(!value.freeDay && value.started && !value.payer){
    value.freeDay=istanbulDay.format(new Date((value.until-900)*1000));
  }
  if(['offer','active'].includes(value.status) && value.until<=now) value.status='ended';
  if(action==='join'){
    if(data.role==='payer' && value.balance<25) throw Error('Başlatmak için 25 deneme jetonu gerekli.');
    if(data.role==='guest' && value.freeDay===day) throw Error('Bugünkü ücretsiz sohbet hakkını kullandın.');
    value={balance:value.balance,freeDay:value.freeDay,id:demoID(),status:'offer',payer:data.role==='payer',until:now+45,messages:[],started:false};
  } else if(action==='accept' && value.status==='offer'){
    value.status='active';
    value.started=true;
    value.until=now+900;
    if(value.payer) value.balance-=25;
    else value.freeDay=day;
    value.messages=[{id:demoID(),body:'Selam! Bu, örnek bir sohbet mesajı.',mine:false}];
  } else if(action==='message' && value.status==='active'){
    value.messages.push({id:demoID(),body:data.body,mine:true});
  } else if(action==='leave'||action==='block'){
    value.status='ended';
  } else if(action==='reset'||action==='cancel'){
    value={status:'idle',balance:value.balance,freeDay:value.freeDay};
  } else if(action==='demo-topup'){
    const pack=tokenPacks.find(([amount])=>amount===data.amount);
    if(!pack) throw Error('Bir jeton paketi seç.');
    value.balance+=pack[0];
  } else if(action==='extend' && value.status==='active'){
    const pack=timePacks.find(([minutes])=>minutes===Number(data.minutes));
    if(value.lastExtension!==data.nonce){
      if(!pack||value.balance<pack[1]) throw Error('Süreyi uzatmak için yeterli jetonun yok.');
      value.balance-=pack[1];
      value.until+=pack[0]*60;
      value.lastExtension=data.nonce;
    }
  }
  localStorage.setItem(key,JSON.stringify(value));
  return {...value,now,purchases:false,freeRemaining:Number(value.freeDay!==day)};
}

function callChat(action,data={}) {
  return demo ? Promise.resolve().then(()=>demoChat(action,data)) : api('/chat/'+action,data);
}

function chatAction(label,action,style='secondary',data='') {
  return '<button type="button" class="'+style+'" data-chat="'+action+'" '+data+'>'+label+'</button>';
}

function chatClock() {
  if(!roomState) return '';
  const seconds=Math.max(0,roomState.until-roomState.now-(timestamp()-lastLoad));
  return String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');
}

function mountChat() {
  if(page!=='sohbet') return;
  if(chatAccount!==me?.name){
    chatAccount=me?.name;
    roomState=null;
    renderedRoom='';
    chatError='';
  }
  if(!screen.querySelector('#chat-view')){
    screen.innerHTML='<h1 class="page-title">Anonim Sohbet</h1><div id="chat-view" class="stack"></div>';
    renderedRoom='';
  }
  drawChat();
  if(me && !roomState && !chatError) pollChat();
}

function drawChat() {
  const view=document.getElementById('chat-view');
  if(page!=='sohbet'||!view) return;
  const state=roomState;
  document.body.classList.toggle('chat-focus',Boolean(me&&state?.started));
  const signature=JSON.stringify([me?.name,state?.id,state?.status,state?.accepted,state?.balance,state?.freeRemaining,state?.purchases,chatError]);
  if(signature!==renderedRoom){
    const draft=view.querySelector('[name=body]')?.value || '';
    const termsChecked=view.querySelector('#chat-terms')?.checked;
    renderedRoom=signature;
    if(!me){
      view.innerHTML='<section class="card stack"><h2>15 dakika yazış</h2><p>İkiniz de kabul edince sohbet başlar. Bir eşleşmeye katılmak için hesabına giriş yap.</p>'+button(demo?'Deneme profili oluştur':'Giriş yap','login','','primary')+'</section>';
    } else if(chatError){
      view.innerHTML='<p class="error">'+e(chatError)+'</p>'+chatAction('Tekrar dene','reload');
    } else if(!state){
      view.innerHTML='<p class="muted">Sohbet yükleniyor…</p>';
    } else if(state.status==='idle'){
      const canJoin=state.freeRemaining!==0;
      view.innerHTML='<section class="hero"><span class="eyebrow">✦ 15 DAKİKA · YAZILI</span><h2 style="font-size:1.8rem">Bir sohbet başlat</h2><p>Birbirinizi takma adla görürsünüz. İki taraf kabul edince süre başlar.</p></section>'+
        '<section class="card stack"><div class="wallet-row"><strong>Bakiye · '+state.balance+(demo?' deneme jetonu':' jeton')+'</strong>'+chatAction('Jeton satın al','shop')+'</div>'+
        '<div class="daily-free"><strong>Günde 1 ücretsiz sohbet</strong><p class="meta">'+
        (canJoin?'Bugün 1 hakkın var. Eşleşme başlayınca kullanılır.':'Bugünkü hakkını kullandın. Gece 00.00’da yenilenir (Türkiye saati).')+'</p></div>'+
        '<label class="check"><input id="chat-terms" type="checkbox" '+(termsChecked?'checked':'')+'><span><a href="/kurallar" data-policy="kurallar">Sohbet kurallarını</a> kabul ediyorum.</span></label>'+
        chatAction('25 jetonla başlat','payer','primary')+chatAction(canJoin?'Ücretsiz katıl':'Ücretsiz hak kullanıldı','guest','secondary',canJoin?'':'disabled')+
        (demo?'<p class="meta">Deneme · Örnek sohbet eşleşmesi.</p>':'')+'</section>';
    } else if(state.status==='waiting'){
      view.innerHTML='<section class="card stack"><h2>Eşleşme aranıyor</h2><p class="muted">Sohbet başlayana kadar jeton harcanmaz.</p>'+chatAction('Aramayı durdur','cancel')+'</section>';
    } else if(state.status==='offer'){
      view.innerHTML='<section class="card stack"><h2>Eşleşme bulundu</h2><p class="meta">Kalan süre <strong data-chat-clock>'+chatClock()+'</strong></p><p>'+
        (state.payer?'Sohbet başlarsa 25 jeton düşer.':'Bu sohbete ücretsiz katılırsın.')+'</p>'+
        (state.accepted?'<p>Karşı tarafın yanıtı bekleniyor.</p>':chatAction('Kabul et','accept','primary'))+
        chatAction('Vazgeç','leave')+'</section>';
    } else {
      const activeRoom=state.status==='active';
      view.innerHTML='<section class="'+(state.started?'chat-room':'card stack')+'"><header class="chat-header">'+
        '<button type="button" class="chat-back" data-page="akis" aria-label="Akışa dön">‹</button>'+
        '<span class="room-avatar" aria-hidden="true">✦</span><div class="room-name"><h2>Anonim sohbet</h2><p class="meta">'+
        (activeRoom?'Kalan süre <strong class="time-pill" data-chat-clock>'+chatClock()+'</strong>':'Sohbet sona erdi.')+'</p></div>'+
        (state.started?chatAction('⋯','options','chat-overflow','aria-label="Seçenekler"'):'')+'</header>'+
        (activeRoom?'<div class="extension-bar"><span class="meta">Bakiye · '+state.balance+' jeton</span>'+chatAction('Süreyi uzat','extension')+'</div>':'')+
        (state.started?'<div id="chat-log" class="chat-log" role="log" aria-label="Sohbet mesajları"></div>':'')+
        (activeRoom?'<form class="chat-composer" data-chat-form="message"><textarea aria-label="Mesaj" name="body" rows="1" maxlength="350" required placeholder="Mesaj yaz…"></textarea><button type="submit" class="primary">Gönder</button></form>':'<div class="chat-composer">'+chatAction('Sohbet ana sayfası','reset','primary')+'</div>')+
        '</section>';
      if(draft && state.status==='active') view.querySelector('[name=body]').value=draft;
    }
  }
  const log=document.getElementById('chat-log');
  if(log && state?.messages){
    const ids=state.messages.map(m=>m.id).join(',');
    if(log.dataset.ids!==ids){
      const pinned=log.scrollHeight-log.scrollTop-log.clientHeight<80;
      const ownMessage=state.messages.at(-1)?.mine;
      const previousScroll=log.scrollTop;
      log.dataset.ids=ids;
      log.innerHTML=state.messages.map(m=>'<div class="bubble '+(m.mine?'mine':'')+'"><span><span class="message-author">'+(m.mine?'Sen':'Anonim')+'</span><span>'+e(m.body)+'</span></span>'+
        (m.mine?'':chatAction('⋯','report-message','close','data-message="'+e(m.id)+'" aria-label="Mesajı bildir"'))+'</div>').join('');
      if(!ids) log.textContent=state.status==='active'?'Sohbet başladı. İlk mesajı gönder.':'Bu sohbette mesaj yok.';
      log.scrollTop=pinned||ownMessage?log.scrollHeight:previousScroll;
    }
  }
  const clock=view.querySelector('[data-chat-clock]');
  if(clock) clock.textContent=chatClock();
}

function updateChat(value) {
  roomState=value;
  lastLoad=timestamp();
  chatError='';
  drawChat();
}

async function pollChat() {
  if(page!=='sohbet'||!me||getStatePending||chatBusy||document.hidden) return;
  getStatePending=true;
  lastPoll=Date.now();
  const account=me.name;
  try {
    const value=await callChat('state');
    if(me?.name===account) updateChat(value);
  } catch(error) {
    if(!roomState && me?.name===account){chatError=error.message;drawChat();}
  } finally {getStatePending=false;}
}

setInterval(()=>{
  const clock=document.querySelector('[data-chat-clock]');
  if(clock) clock.textContent=chatClock();
  if(page==='sohbet' && me && !chatError &&
    Date.now()-lastPoll >= (roomState?.status==='idle'?8000:1800)) pollChat();
},600);

function chatReport(target) {
  show('Sohbeti bildir','<form data-chat-form="report"><div class="error" role="alert"></div><input type="hidden" name="target" value="'+e(target)+'"><label>Bildirim nedeni<select name="reason">'+reasons.map(r=>'<option>'+e(r)+'</option>').join('')+'</select></label><button class="primary" type="submit">Bildirimi gönder</button></form>');
}

function openTokenShop(state) {
  const playAvailable = state.purchases && nativePlay;
  const content = tokenPacks.map(([amount,tl])=>{
    const id='kivilcim_jeton_'+amount;
    const price=demo?tl+' TL':playPrices[id];
    const label='<span>'+amount+' jeton</span><strong>'+e(price||'')+'</strong>';
    if(demo) return chatAction(label,'demo-topup','pack-row','data-value="'+amount+'" aria-label="'+amount+' deneme jetonu ekle"');
    if(playAvailable && price) return '<a class="pack-row" href="/android-buy?account='+e(state.account)+'&amp;product='+id+'">'+label+'</a>';
    return '<div class="pack-row unavailable">'+label+'</div>';
  }).join('');
  const hint = demo ? 'Deneme jetonu ekler. Ücret alınmaz.' : playAvailable
    ? 'Fiyat ve ödeme Google Play üzerinden gösterilir.'
    : (state.purchases?'Satın almak için Kıvılcım’ın Google Play sürümünü aç.':'Jeton satışı henüz açılmadı.');
  show('Jeton satın al','<section id="token-shop" class="stack"><p class="meta">'+hint+'</p>'+content+'</section>');
}

window.kivilcimPrices=payload=>{
  playPrices=JSON.parse(payload);
  if(modal.open && sheet.querySelector('#token-shop') && roomState) openTokenShop(roomState);
};

function openExtension() {
  show('Süreyi uzat','<section class="stack"><p class="meta">Ek süre ikiniz için de geçerli. Jeton senin bakiyenden düşer.</p>'+
    timePacks.map(([minutes,cost])=>chatAction('<span>+'+minutes+' dakika</span><strong>'+cost+' jeton</strong>',
      'choose-extension','pack-row','data-value="'+minutes+'" aria-label="+'+minutes+' dakika, '+cost+' jeton"')).join('')+'</section>');
}

async function chatModeration() {
  const rows=await api('/chat-reports');
  show('Sohbet bildirimleri','<div class="stack admin">'+(rows.length?rows.map(r=>'<form data-chat-form="moderate"><input type="hidden" name="id" value="'+e(r.id)+'"><strong>'+e(r.reason)+'</strong><p class="body">'+e(r.evidence||'Bildirimde mesaj örneği yok.')+'</p><div class="error" role="alert"></div><label>Karar<select name="decision"><option value="dismiss">Bildirimi kapat</option><option value="end">Sohbeti kapat</option><option value="suspend">Hesabı askıya al</option></select></label><button class="primary" type="submit">Uygula</button></form>').join(''):'<p>Bekleyen bildirim yok.</p>')+'</div>');
}

document.addEventListener('click',async event=>{
  const target=event.target.closest('[data-chat]');
  if(!target||chatBusy||getStatePending&&target.dataset.chat==='reload') return;
  const action=target.dataset.chat;
  if(action==='shop' && roomState){openTokenShop(roomState);return;}
  if(action==='reload'){
    chatError='';
    pollChat();
    return;
  }
  chatBusy=true;
  let performed=action;
  try {
    let data={id:roomState?.id};
    if(action==='demo-topup'){
      if(!demo) return;
      data={amount:Number(target.dataset.value)};
    }
    if(action==='extension' && roomState?.status==='active'){openExtension();return;}
    if(action==='choose-extension'){
      const [minutes,cost]=timePacks.find(([value])=>value===Number(target.dataset.value));
      if(roomState.balance<cost){toast('Süreyi uzatmak için yeterli jetonun yok.');return;}
      show('Uzatmayı onayla','<div class="stack"><p>'+cost+' jeton karşılığında sohbete '+minutes+' dakika eklenecek.</p>'+
        chatAction('Uzatmayı onayla','extend','primary','data-value="'+minutes+'" data-nonce="'+demoID()+'"')+'</div>');
      return;
    }
    if(action==='extend') data={id:roomState.id,minutes:target.dataset.value,nonce:target.dataset.nonce};
    if(action==='moderation'){await chatModeration();return;}
    if(action==='options'){
      show('Sohbet seçenekleri','<div class="sheet-actions">'+chatAction('Kullanıcıyı bildir','report-user')+
        chatAction('Kullanıcıyı engelle','confirm-block','danger')+
        (roomState.status==='active'?chatAction('Sohbeti bitir','confirm-leave','danger'):'')+'</div>');
      return;
    }
    if(action==='report-message'||action==='report-user'){chatReport(target.dataset.message||'user');return;}
    if(action==='confirm-block'||action==='confirm-leave'){
      show(action==='confirm-block'?'Kullanıcıyı engelle':'Sohbeti bitir',
        '<p>Sohbet kapanacak. '+(roomState.payer && roomState.status==='active'?'Başlangıçta kullanılan 25 jeton geri yüklenmez.':'')+'</p><div class="inline" style="margin-top:12px">'+button('Vazgeç','close')+
        chatAction('Onayla',action==='confirm-block'?'block':'leave','danger')+'</div>');
      return;
    }
    if(action==='payer'||action==='guest'){
      const terms=document.getElementById('chat-terms');
      if(!terms.checked){toast('Katılmak için sohbet kurallarını kabul et.');terms.focus();return;}
      data={role:action,terms:'yes'};
      performed='join';
    }
    await getChatAction(performed,data);
    if(modal.open) modal.close();
    if(performed==='block') toast('Kullanıcı engellendi.');
    if(performed==='demo-topup') toast(data.amount+' deneme jetonu eklendi.');
    if(performed==='extend') toast('Sohbete '+data.minutes+' dakika eklendi.');
  } catch(error) {toast(error.message);}
  finally {chatBusy=false;}
});

async function getChatAction(action,data) {
  // A poll may finish after a user action. Wait for it before rendering the action result.
  const value=await callChat(action,data);
  while(getStatePending) await new Promise(resolve=>setTimeout(resolve,30));
  updateChat(value);
}

document.addEventListener('submit',async event=>{
  const form=event.target;
  const action=form.dataset.chatForm;
  if(!action) return;
  event.preventDefault();
  if(chatBusy) return;
  chatBusy=true;
  const submit=form.querySelector('[type=submit]');
  submit.disabled=true;
  const data=Object.fromEntries(new FormData(form));
  try{
    if(action==='moderate'){
      await api('/chat-moderate',data);
      modal.close();
      toast('Karar uygulandı.');
    }else{
      data.id=roomState?.id;
      if(action==='message'){
        data.body=data.body.trim();
        if(!data.body) return;
        if(form.dataset.lastBody!==data.body){
          form.dataset.nonce=demoID();
          form.dataset.lastBody=data.body;
        }
        data.nonce=form.dataset.nonce;
      }
      await getChatAction(action,data);
      if(action==='message'){
        delete form.dataset.nonce;
        delete form.dataset.lastBody;
        form.reset();
      }else{
        modal.close();
        toast(demo?'Deneme bildirimi tamamlandı.':'Bildirimin alındı.');
      }
    }
  }catch(error){
    const field=form.querySelector('.error');
    if(field) field.textContent=error.message;else toast(error.message);
  }finally{submit.disabled=false;chatBusy=false;}
});

window.kivilcimPurchase=async (token,interactive)=>{
  if(demo || delivered.has(token)) return;
  delivered.add(token);
  try {
    const result=await callChat('purchase',{token});
    if(result.pending){delivered.delete(token);return;}
    if(interactive||!result.restored) toast('Jetonlar hesabına eklendi.');
    if(roomState) {roomState.balance=result.balance;drawChat();}
    pollChat();
  } catch(error) {
    delivered.delete(token);
    if(interactive) toast(error.message);
  }
};

if(page==='sohbet') mountChat();
