'use strict';
const demo = location.protocol === 'file:' || location.hostname === 'preview.kivilcim.local' || new URLSearchParams(location.search).has('demo') && ['localhost','127.0.0.1'].includes(location.hostname);
const clubs = {
  gunun: ['✦','Günün Sorusu','Her gün yeni bir sohbet.'],
  sehir: ['⌂','Şehir Keşfi','Mahallenin sevdiğin köşelerini paylaş.'],
  kultur: ['♫','Müzik ve Kültür','Bir şarkı, film ya da kitap öner.'],
  hobi: ['✿','Hobi ve Üretim','Ürettiğini ve öğrenmek istediğini anlat.'],
  mola: ['☕','Kahve Molası','Günün küçük anlarına yer aç.']
};
const questions = [
  'Bu hafta kendin için yaptığın en güzel küçük şey neydi?',
  'Şehrinde birine yalnızca tek bir yer gösterecek olsan nereye götürürdün?',
  'Tekrar ilk kez dinlemek isteyeceğin şarkı hangisi?',
  'Bir saatliğine yeni bir hobi denesen neyi seçerdin?',
  'Gününü güzelleştiren küçük bir alışkanlığın var mı?',
  'Bir arkadaşına hangi filmi hiç düşünmeden önerirsin?',
  'Son zamanlarda birinden öğrendiğin güzel bir şey ne?'
];
const today = new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const day = Math.floor(Date.parse(today+'T00:00:00Z')/86400000);
const question = questions[(Number.isFinite(day) ? day : 0)%questions.length];
const reasons = ['Taciz veya zorbalık','Nefret veya tehdit','Çocuk güvenliği','Cinsel içerik','Kişisel bilgi paylaşımı','Spam veya dolandırıcılık','Diğer'];
const pages = ['akis','kulupler','kayitlar','sohbet','profil'];
const screen = document.getElementById('screen');
const modal = document.getElementById('modal');
const sheet = document.getElementById('sheet');
const notice = document.getElementById('notice');
const e = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const button = (label,action,attrs='',kind='secondary') => '<button type="button" class="'+kind+'" data-do="'+action+'" '+attrs+'>'+label+'</button>';
const sample = () => [
  {id:'ornek-1',author:'Deniz',club:'sehir',body:'Beykoz’da sabah sahil yürüyüşü ve çay. İstanbul’da böyle sakin kalmış başka nereler var?',score:12,replyCount:1,replies:[{id:'ornek-c1',author:'Ece',body:'Kanlıca’da sabah sahil tarafı da çok güzel.'}]},
  {id:'ornek-2',author:'Ece',club:'kultur',body:'Bir şarkıyla bütün bir mevsimi hatırlamak çok garip. Sizin kış şarkınız hangisi?',score:8,replyCount:0,replies:[]}
];
function fresh() {return {me:null,posts:sample(),liked:[],saved:[],blocked:[],reports:[]};}
function readDemo() {
  try {return JSON.parse(localStorage.getItem('kivilcim.demo.v1')) || fresh();}
  catch {return fresh();}
}
let local = demo ? readDemo() : null;
let me = null, posts = [], filter = 'all', active = '', busy = false, timer;
let feedOrder = "latest";
let page = 'akis', revision = 0;
const demoID = () => 'demo-'+crypto.getRandomValues(new Uint32Array(3)).join('-');
const viewPost = p => ({...p,replies:p.replies.filter(c=>!local.blocked.includes(c.author)),liked:local.liked.includes(p.id),saved:local.saved.includes(p.id)});
function demoApi(path,data) {
  const p = local.posts.find(item=>item.id===data?.id || item.id===path.split('/')[2]);
  switch(path) {
    case '/me': return local.me;
    case '/feed': return local.posts.filter(item=>!local.blocked.includes(item.author)).map(viewPost);
    case '/signup':
      if (local.me) throw Error('Bu cihazda zaten bir deneme profili var.');
      if (!data.adult || !data.terms || !validBirth(data.birth)) throw Error('Devam etmek için 18 yaş ve topluluk kuralları koşullarını karşılamalısın.');
      local.me={name:data.name.trim()}; break;
    case '/logout': return null;
    case '/post': local.posts.unshift({id:demoID(),author:local.me.name,mine:true,club:data.club,body:data.body,score:0,replyCount:0,replies:[]});break;
    case '/reply': p.replies.push({id:demoID(),author:local.me.name,mine:true,body:data.body});p.replyCount++;break;
    case '/like': {
      const i=local.liked.indexOf(p.id);
      if(i<0){local.liked.push(p.id);p.score++;}else{local.liked.splice(i,1);p.score--;}
      break;
    }
    case '/save': local.saved=local.saved.includes(p.id)?local.saved.filter(x=>x!==p.id):[...local.saved,p.id];break;
    case '/block': if(!local.blocked.includes(data.target)) local.blocked.push(data.target);break;
    case '/unblock': local.blocked=local.blocked.filter(a=>a!==data.target);break;
    case '/blocks': return local.blocked.map(name=>({name,id:name}));
    case '/report': local.reports.push(data);break;
    case '/delete-post': local.posts=local.posts.filter(x=>x.id!==data.id||!x.mine);break;
    case '/delete-reply':
      for(const row of local.posts){row.replies=row.replies.filter(x=>x.id!==data.id||!x.mine);row.replyCount=row.replies.length;}
      break;
    case '/delete-account': local=fresh();localStorage.removeItem('kivilcim.demo.chat.v2');break;
    default: if (path.startsWith('/post/')) return p ? viewPost(p) : null;
  }
  localStorage.setItem('kivilcim.demo.v1',JSON.stringify(local));
  return true;
}
async function api(path,data) {
  if(demo) return demoApi(path,data);
  let response;
  try {
    response=await fetch('/api'+path,{method:data?'POST':'GET',credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(12000),...(data?{headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}:{})});
  } catch {throw Error('Bağlantı kurulamadı. İnternetini kontrol edip tekrar dene.');}
  const value=await response.json().catch(()=>({error:'Sunucudan geçerli yanıt alınamadı. Tekrar dene.'}));
  if(!response.ok) throw Error(value.error || 'İşlem tamamlanamadı.');
  return value.result;
}
function toast(message) {
  notice.textContent=message;
  clearTimeout(timer);
  timer=setTimeout(()=>{notice.textContent='';},3800);
}
function show(title,html) {
  sheet.innerHTML='<div class="sheet-title"><h2 id="dialog-title">'+title+'</h2>'+button('×','close','aria-label="Kapat"','close')+'</div>'+html;
  modal.setAttribute('aria-labelledby','dialog-title');
  if(!modal.open) modal.showModal();
}
function validBirth(value) {
  const limit=(Number(today.slice(0,4))-18)+today.slice(4);
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && value<=(limit) && value>='1900-01-01';
}
function auth(signup=demo) {
  show(demo?'Deneme profili':signup?'Hesap oluştur':'Giriş yap',
    '<form data-form="'+(signup?'signup':'login')+'"><div class="error" role="alert"></div>'+
    (demo?'<p class="muted">Bu profili sadece bu telefonda denersin. Örnek paylaşımlar diğer kullanıcılara gönderilmez.</p>':'')+
    '<label>Kullanıcı adı<input name="name" autocomplete="username" minlength="3" maxlength="24" required></label>'+
    (demo?'':'<label>Şifre<input name="password" type="password" autocomplete="'+(signup?'new-password':'current-password')+'" minlength="10" maxlength="128" required></label>')+
    (signup?'<label>Doğum tarihi<input name="birth" type="date" required min="1900-01-01" max="'+today+'"></label><label class="check"><input name="adult" type="checkbox" value="yes" required><span>18 yaşımı doldurdum.</span></label><label class="check"><input name="terms" type="checkbox" value="yes" required><span><a href="/kurallar" data-policy="kurallar">Topluluk kurallarını ve kullanım şartlarını</a> kabul ediyorum. <a href="/gizlilik" data-policy="gizlilik">Gizlilik politikası</a></span></label>':'')+
    '<button class="primary" type="submit">'+(signup?'Profil oluştur':'Giriş yap')+'</button></form>'+
    (demo?'':button(signup?'Zaten hesabım var':'Yeni hesap oluştur',signup?'login':'signup','','close')));
}
function compose(club=filter) {
  if(!me) return auth();
  show('Yeni paylaşım','<form data-form="post"><div class="error" role="alert"></div><label>Kulüp<select name="club">'+Object.entries(clubs).map(([k,v])=>'<option value="'+k+'" '+(k===club?'selected':'')+'>'+v[1]+'</option>').join('')+'</select></label><label>Ne paylaşmak istersin?<textarea name="body" rows="4" minlength="3" maxlength="500" placeholder="Sohbeti başlat…" required></textarea></label><button class="primary" type="submit">Paylaş</button></form>');
}
function item(p) {
  const id=e(p.id);
  return '<article class="card feed-post tone-'+e(p.club)+'"><div class="entry"><span class="avatar" aria-hidden="true">'+e(p.author.slice(0,1).toLocaleUpperCase('tr'))+'</span><div><strong>'+e(p.author)+'</strong><br><span class="tag">'+e(clubs[p.club]?.[1])+'</span></div>'+button('⋯','post-menu','data-id="'+id+'" aria-label="'+e(p.author)+' paylaşım seçenekleri"','close')+'</div><p class="body">'+e(p.body)+'</p><div class="actions">'+button('✦ '+p.score,'like','aria-label="Destekle, '+p.score+'" aria-pressed="'+!!p.liked+'" data-id="'+id+'"','')+button('Yorum '+p.replyCount,'comments','data-id="'+id+'"','')+button(p.saved?'◆':'◇','save','aria-label="Kaydet" aria-pressed="'+!!p.saved+'" data-id="'+id+'"','')+'</div></article>';
}
function display() {
  if(page!=='sohbet') document.body.classList.remove('chat-focus');
  for(const tab of document.querySelectorAll('[data-page]')){
    if(tab.dataset.page===page) tab.setAttribute('aria-current','page');else tab.removeAttribute('aria-current');
  }
  document.getElementById('profile').textContent=me ? me.name[0].toLocaleUpperCase('tr') : '☺';
  const feed=(set,empty)=>set.length?set.map(item).join(''):'<p class="empty muted">'+empty+'</p>';
  if(page==='sohbet'){ if(typeof mountChat==='function') mountChat();return; }
  if(page==='profil') {
    screen.innerHTML='<h1 class="page-title">Profil</h1><div class="stack"><div class="card stack">'+(me?'<h2>'+e(me.name)+'</h2>'+'<button type="button" class="secondary" data-page="kayitlar">Kaydedilen paylaşımlar</button>'+button('Engellenen kullanıcılar','blocks')+(demo?'':button('Çıkış yap','logout'))+button('Hesabımı sil','delete-account','','danger'):'<p>Paylaşımlara katılmak için bir profil oluştur.</p>'+button(demo?'Deneme profili oluştur':'Giriş yap veya hesap oluştur','login','','primary'))+'</div><div class="card stack"><a href="/kurallar" data-policy="kurallar">Topluluk ve kullanım kuralları</a><a href="/gizlilik" data-policy="gizlilik">Gizlilik ve veri silme</a><a href="/cocuk-guvenligi" data-policy="cocuk-guvenligi">Çocuk güvenliği</a>'+(me?.moderator?button('Moderasyon kuyruğu','moderation')+'<button class="secondary" data-chat="moderation">Sohbet bildirimleri</button>':'')+'</div>'+(demo?'<p class="meta">Deneme sürümü · Veriler bu cihazda tutulur.</p>':'')+'</div>';return;
  }
  if(page==='kulupler') {
    screen.innerHTML='<div class="page-intro"><h1 class="page-title">Kulüpleri keşfet</h1><p class="muted">İlgini çeken konunun akışına katıl.</p></div><div class="grid club-grid">'+
      Object.entries(clubs).map(([key,[icon,title,description]])=>'<button class="club tone-'+key+'" data-do="club" data-id="'+key+'"><span class="symbol" aria-hidden="true">'+icon+'</span><h2>'+title+'</h2><p>'+description+'</p></button>').join('')+'</div>';return;
  }
  if(page==='kayitlar') {
    screen.innerHTML='<h1 class="page-title">Kaydedilenler</h1>'+feed(posts.filter(p=>p.saved),me?'Kaydettiğin paylaşımlar burada görünecek.':'Paylaşımları kaydetmek için profil oluştur.');return;
  }
  const visiblePosts=posts.filter(p=>filter==='all'||p.club===filter);
  if(feedOrder==='popular') visiblePosts.sort((a,b)=>(b.score+b.replyCount*2)-(a.score+a.replyCount*2));
  const topicButtons=[['all',['◉','Hepsi']],...Object.entries(clubs)].map(([key,[icon,title]])=>
    button('<span aria-hidden="true">'+icon+'</span>'+title,'filter','data-id="'+key+'" aria-pressed="'+(filter===key)+'"','tone-'+key+(filter===key?' selected':''))).join('');
  screen.innerHTML='<section class="hero feed-hero"><span class="eyebrow">✦ GÜNÜN SORUSU</span><h1>'+e(question)+'</h1>'+button('Cevabını paylaş','daily','','primary')+'</section>'+
    '<div class="section"><h2>Topluluk akışı</h2>'+button('Yenile','refresh','','')+'</div>'+
    '<div class="chips topics" aria-label="Akış konuları">'+topicButtons+'</div>'+
    '<div class="feed-tabs" aria-label="Akış sıralaması">'+button('Son paylaşımlar','feed-order','data-id="latest" aria-pressed="'+(feedOrder==='latest')+'"','')+
    button('Öne çıkanlar','feed-order','data-id="popular" aria-pressed="'+(feedOrder==='popular')+'"','')+'</div>'+
    feed(visiblePosts,'Burada henüz paylaşım yok. İlk paylaşımı sen yapabilirsin.')+(demo?'<p class="meta">Deneme akışı · Örnek içerikler</p>':'');
}
async function refresh() {
  const rev=++revision;
  const [user,feed]=await Promise.all([api('/me'),api('/feed')]);
  if(rev!==revision) return;
  me=user;posts=feed;display();
}
async function comments(id) {
  const post=await api('/post/'+encodeURIComponent(id));
  if(!post) throw Error('Paylaşım artık kullanılamıyor.');
  active=id;
  show('Yorumlar','<p class="body">'+e(post.body)+'</p>'+
    (post.replies.length?post.replies.map(c=>'<div class="reply"><strong>'+e(c.author)+'</strong><p>'+e(c.body)+'</p>'+(c.mine?button('Yorumu sil','confirm-delete-reply','data-id="'+e(c.id)+'"',''):button('Yorum seçenekleri','reply-menu','data-id="'+e(c.id)+'"',''))+'</div>').join(''):'<p class="muted">Henüz yorum yok.</p>')+
    (me?'<form data-form="reply" style="margin-top:12px"><div class="error" role="alert"></div><label>Yorum yaz<textarea name="body" rows="2" minlength="2" maxlength="350" required></textarea></label><input type="hidden" name="id" value="'+e(id)+'"><button type="submit" class="primary">Gönder</button></form>':button('Yorum yazmak için giriş yap','login')));
}
function menu(type,id,author,mine) {
  show(type==='post'?'Paylaşım seçenekleri':'Yorum seçenekleri','<div class="sheet-actions">'+
    (mine?button('Sil','confirm-delete-'+type,'data-id="'+e(id)+'"','danger'):
      button('İçeriği bildir','report','data-type="'+type+'" data-id="'+e(id)+'"')+
      button('Kullanıcıyı bildir','report','data-type="user" data-id="'+e(author)+'"')+
      button('Kullanıcıyı engelle','confirm-block','data-id="'+e(author)+'"','danger'))+'</div>');
}
function confirmAction(title,copy,action,id='') {
  show(title,'<p>'+copy+'</p><div class="inline" style="margin-top:12px">'+button('Vazgeç','close')+button('Onayla',action,'data-id="'+e(id)+'"','danger')+'</div>');
}
const policyNames={kurallar:'Topluluk kuralları',gizlilik:'Gizlilik ve hesap silme','cocuk-guvenligi':'Çocuk güvenliği'};
async function policy(key) {
  if (!demo) {location.assign('/'+key);return;}
  const copy={
    kurallar:'Kıvılcım 18 yaş ve üzeri içindir. Taciz, nefret söylemi, tehdit, başkalarının özel bilgilerini ifşa etme, cinsel istismar, yasa dışı içerik, spam ve dolandırıcılık yasaktır. İçerik ve kullanıcıları seçenek menüsünden bildirebilir veya engelleyebilirsin.',
    gizlilik:'Deneme sürümü profilini ve etkileşimlerini yalnızca bu cihazda saklar. Profil ekranındaki Hesabımı sil seçeneği bu verileri kaldırır.',
    'cocuk-guvenligi':'Çocukların cinsel istismarı ve sömürüsüne yönelik her türlü içerik, yönlendirme ve davranış yasaktır. İçeriği paylaşmadan paylaşım menüsündeki Çocuk güvenliği kategorisiyle bildir.'
  };
  if(modal.open){
    const previous=document.createElement('div');
    previous.className='card meta';
    previous.textContent=copy[key];
    sheet.append(previous);
    previous.scrollIntoView({block:'nearest'});
    return;
  }
  show(policyNames[key],'<p>'+copy[key]+'</p>');
}
function go(next) {if(location.hash!=='#'+next) location.hash=next;else {page=next;display();}}
window.addEventListener('hashchange',()=>{
  const next=location.hash.slice(1);
  page=pages.includes(next)?next:'akis';display();scrollTo(0,0);
});
document.addEventListener('click',async event=>{
  const target=event.target.closest('button,[data-policy]');
  if(!target||target.disabled) return;
  if(target.dataset.policy){
    if(!demo&&!modal.open) return;
    event.preventDefault();
    await policy(target.dataset.policy);return;
  }
  if(target.id==='profile') return go('profil');
  if(target.dataset.page) return go(target.dataset.page);
  const {do:action,id,type}=target.dataset;
  if(!action) return;
  if(action==='close') return modal.close();
  if(busy) return;
  busy=true;
  try {
    switch(action) {
      case 'signup':auth(true);break;
      case 'login':auth();break;
      case 'compose':compose();break;
      case 'daily':compose('gunun');break;
      case 'refresh':await refresh();toast('Akış güncellendi.');break;
      case 'club':filter=id;feedOrder='latest';go('akis');break;
      case 'filter':filter=id;display();break;
      case 'feed-order':feedOrder=id;display();break;
      case 'comments':await comments(id);break;
      case 'post-menu':{const p=posts.find(row=>row.id===id);if(p) menu('post',id,p.authorId||p.author,p.mine);break;}
      case 'reply-menu':{const p=await api('/post/'+encodeURIComponent(active));const c=p?.replies.find(row=>row.id===id);if(c) menu('reply',id,c.authorId||c.author,c.mine);break;}
      case 'like':case 'save':
        if(!me){auth();break;}await api('/'+action,{id});await refresh();break;
      case 'report':
        if(!me){auth();break;}
        show('Bildir','<form data-form="report"><div class="error" role="alert"></div><input type="hidden" name="target" value="'+e(id)+'"><input type="hidden" name="type" value="'+e(type)+'"><label>Bildirim nedeni<select name="reason">'+reasons.map(r=>'<option>'+r+'</option>').join('')+'</select></label><button type="submit" class="primary">Bildirimi gönder</button></form>');break;
      case 'confirm-block':
        if(!me){auth();break;}
        confirmAction('Kullanıcıyı engelle','Bu kullanıcının paylaşımları ve yorumları akışından kaldırılacak.','block',id);break;
      case 'block':await api('/block',{target:id});modal.close();await refresh();toast('Kullanıcı engellendi.');break;
      case 'blocks':{
        const list=await api('/blocks');
        show('Engellenen kullanıcılar',list.length?'<div class="stack">'+list.map(a=>'<div class="inline"><strong>'+e(a.name)+'</strong>'+button('Engeli kaldır','unblock','data-id="'+e(a.id)+'"')+'</div>').join('')+'</div>':'<p class="muted">Engellenen kullanıcı yok.</p>');break;
      }
      case 'unblock':await api('/unblock',{target:id});modal.close();await refresh();toast('Engel kaldırıldı.');break;
      case 'confirm-delete-post':case 'confirm-delete-reply':confirmAction('İçeriği sil','Silinen içerik geri getirilemez.',action.replace('confirm-',''),id);break;
      case 'delete-post':case 'delete-reply':await api('/'+action,{id});modal.close();await refresh();toast('İçerik silindi.');break;
      case 'logout':await api('/logout',{});await refresh();break;
      case 'delete-account':
        show('Hesabı sil','<p>Profilin, gönderilerin ve yorumların kalıcı olarak silinecek.</p><form data-form="delete-account"><div class="error" role="alert"></div>'+
        (demo?'':'<label>Şifren<input type="password" name="password" minlength="10" maxlength="128" required></label>')+
        '<label class="check"><input type="checkbox" name="confirm" value="yes" required><span>Hesabımı kalıcı olarak silmek istiyorum.</span></label><button class="danger" type="submit">Hesabımı kalıcı olarak sil</button></form>');break;
      case 'moderation':{
        const reports=await api('/reports');
        show('Moderasyon kuyruğu','<div class="stack admin">'+(reports.length?reports.map(r=>'<form data-form="moderate"><input type="hidden" name="id" value="'+e(r.id)+'"><strong>'+e(r.reason)+'</strong><p class="body">'+e(r.content||'İçerik kaldırılmış')+'</p><div class="error" role="alert"></div><label>Karar<select name="decision"><option value="dismiss">Bildirimi kapat</option>'+(r.type==='user'?'<option value="suspend">Hesabı askıya al</option>':'<option value="remove">İçeriği kaldır</option>')+'</select></label><button class="primary">Uygula</button></form>').join(''):'<p>Bekleyen bildirim yok.</p>')+'</div>');break;
      }
    }
  } catch(error){toast(error.message);}finally{busy=false;}
});
document.addEventListener('submit',async event=>{
  const form=event.target;
  if(!form.dataset.form) return;
  event.preventDefault();
  if(busy) return;
  busy=true;
  const submit=form.querySelector('[type=submit], button');
  submit.disabled=true;
  const action=form.dataset.form;
  const data=Object.fromEntries(new FormData(form));
  const errorBox=form.querySelector('.error');
  errorBox.textContent='';
  try {
    for(const field of ['name','body']) if(field in data) data[field]=data[field].trim();
    if('body' in data && data.body.length<(action==='post'?3:2)) throw Error('Biraz daha uzun bir metin yaz.');
    if('name' in data && !/^[\p{L}\p{N}_-]{3,24}$/u.test(data.name)) throw Error('Kullanıcı adı 3–24 karakter olmalı. Harf, sayı, alt çizgi ve kısa çizgi kullanabilirsin.');
    if(action==='signup' && !validBirth(data.birth)) throw Error('Kıvılcım 18 yaş ve üzeri kullanıcılar içindir.');
    await api('/'+action,data);
    modal.close();
    if(action==='post'){filter=data.club;go('akis');}
    await refresh();
    if(action==='reply') await comments(data.id);
    if(['report','delete-account','post','moderate'].includes(action)){
      toast({report:demo?'Deneme bildirimi kaydedildi.':'Bildirimin alındı.', 'delete-account':'Hesabın silindi.',post:'Paylaşımın yayınlandı.',moderate:'Karar uygulandı.'}[action]);
    }
  } catch(error){if(modal.open) errorBox.textContent=error.message;else toast(error.message);}
  finally{submit.disabled=false;busy=false;}
});
page=pages.includes(location.hash.slice(1))?location.hash.slice(1):'akis';
display();
refresh().catch(error=>toast(error.message));
