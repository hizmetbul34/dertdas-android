'use strict';
const form = document.getElementById('remove-account');
const statusText = document.getElementById('status');
async function send(path, body) {
  const r = await fetch('/api/'+path, {
    method:'POST',credentials:'same-origin',
    headers:{'Content-Type':'application/json'},body:JSON.stringify(body)
  });
  const value = await r.json();
  if(!r.ok) throw Error(value.error || 'İşlem tamamlanamadı.');
}
form.addEventListener('submit',async event=>{
  event.preventDefault();
  const submit=form.querySelector('button');
  submit.disabled=true;
  statusText.textContent='İşlem yapılıyor…';
  const {name,password,confirm}=Object.fromEntries(new FormData(form));
  try {
    await send('login',{name,password});
    await send('delete-account',{password,confirm});
    form.reset();
    statusText.textContent='Hesabın ve ilişkili verilerin silindi.';
  } catch(error) {statusText.textContent=error.message;}
  finally {submit.disabled=false;}
});
