package com.kivilcimtopluluk.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.window.OnBackInvokedDispatcher;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.IOException;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final int BACKGROUND = Color.rgb(20, 19, 24);
    private static final String PREVIEW = "https://preview.kivilcim.local/";
    private WebView webView;
    private FrameLayout root;
    private LinearLayout errorPanel;
    private Uri origin;
    private boolean loadFailed;
    private PlayPurchases purchases;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        origin = Uri.parse(BuildConfig.DEMO ? PREVIEW : BuildConfig.ORIGIN);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().setStatusBarContrastEnforced(false);
            getWindow().setNavigationBarContrastEnforced(false);
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(BACKGROUND);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, windowInsets) -> {
                Insets padding = windowInsets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime()
                );
                view.setPadding(padding.left, padding.top, padding.right, padding.bottom);
                return WindowInsets.CONSUMED;
            });
        } else {
            root.setFitsSystemWindows(true);
        }

        webView = new WebView(this);
        webView.setBackgroundColor(BACKGROUND);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        if (!BuildConfig.DEMO) {
            settings.setUserAgentString(settings.getUserAgentString() + " KivilcimAndroid/2");
            purchases = new PlayPurchases(this);
        }
        webView.setWebViewClient(new KivilcimClient());
        webView.setWebChromeClient(new WebChromeClient());
        root.addView(webView);
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::navigateBack
            );
        }
        if (state == null || webView.restoreState(state) == null) {
            webView.loadUrl(origin.toString());
        }
    }

    private boolean sameOrigin(Uri uri) {
        return "https".equalsIgnoreCase(uri.getScheme()) &&
            origin.getHost().equalsIgnoreCase(uri.getHost()) &&
            (origin.getPort() == -1 ? 443 : origin.getPort()) == (uri.getPort() == -1 ? 443 : uri.getPort());
    }

    private final class KivilcimClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            if (!request.isForMainFrame()) return true;
            Uri uri = request.getUrl();
            if (sameOrigin(uri)) {
                if (!BuildConfig.DEMO && "/android-buy".equals(uri.getPath())) {
                    String account = uri.getQueryParameter("account");
                    if (request.hasGesture() && account != null && account.matches("[a-f0-9]{64}")) {
                        purchases.buy(account, uri.getQueryParameter("product"));
                    }
                    return true;
                }
                return false;
            }
            if ("mailto".equals(uri.getScheme()) && request.hasGesture()) {
                try {
                    startActivity(new Intent(Intent.ACTION_SENDTO, uri));
                } catch (android.content.ActivityNotFoundException ignored) {
                    android.widget.Toast.makeText(MainActivity.this, "E-posta uygulaması bulunamadı.", android.widget.Toast.LENGTH_SHORT).show();
                }
            }
            return true;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            if (!BuildConfig.DEMO) return null;
            if (!sameOrigin(request.getUrl())) return missingAsset();
            String path = request.getUrl().getPath();
            if (path == null || path.equals("/")) path = "/index.html";
            String type;
            switch (path) {
                case "/index.html": type = "text/html"; break;
                case "/style.css": type = "text/css"; break;
                case "/app.js":
                case "/chat.js": type = "text/javascript"; break;
                default: type = null;
            }
            if (type != null) {
                try {
                    return new WebResourceResponse(type, StandardCharsets.UTF_8.name(), getAssets().open(path.substring(1)));
                } catch (IOException ignored) {
                    // The caller receives a local 404 when an asset is missing.
                }
            }
            return missingAsset();
        }

        private WebResourceResponse missingAsset() {
            return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", java.util.Collections.emptyMap(), null);
        }

        @Override
        public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
            loadFailed = false;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (!loadFailed && errorPanel != null) {
                root.removeView(errorPanel);
                errorPanel = null;
            }
            if (!loadFailed && purchases != null && sameOrigin(Uri.parse(url))) purchases.restore();
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) showConnectionError();
        }

        @Override
        public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
            if (request.isForMainFrame()) showConnectionError();
        }
    }

    private void showConnectionError() {
        loadFailed = true;
        if (errorPanel != null) return;
        errorPanel = new LinearLayout(this);
        errorPanel.setBackgroundColor(BACKGROUND);
        errorPanel.setOrientation(LinearLayout.VERTICAL);
        errorPanel.setGravity(Gravity.CENTER);
        int padding = Math.round(24 * getResources().getDisplayMetrics().density);
        errorPanel.setPadding(padding, padding, padding, padding);
        TextView message = new TextView(this);
        message.setTextColor(Color.WHITE);
        message.setTextSize(18);
        message.setGravity(Gravity.CENTER);
        message.setText("Kıvılcım şu anda açılamıyor.\nBağlantını kontrol edip tekrar dene.");
        errorPanel.addView(message);
        Button retry = new Button(this);
        retry.setText("Tekrar dene");
        retry.setOnClickListener(button -> webView.loadUrl(origin.toString()));
        errorPanel.addView(retry);
        root.addView(errorPanel, new FrameLayout.LayoutParams(-1, -1));
    }

    @Override
    public void onBackPressed() {
        navigateBack();
    }

    private void navigateBack() {
        if (errorPanel != null) {
            finish();
            return;
        }
        webView.evaluateJavascript(
            "(()=>{const dialog=document.querySelector('dialog[open]');if(!dialog)return false;dialog.close();return true;})()",
            result -> {
                if ("true".equals(result)) return;
                if (webView.canGoBack()) webView.goBack();
                else finish();
            }
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (purchases != null) purchases.restore();
    }

    @Override
    protected void onDestroy() {
        if (purchases != null) purchases.close();
        super.onDestroy();
    }

    void purchaseNotice(String message) {
        if (!isFinishing() && !isDestroyed()) {
            android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show();
        }
    }

    void deliverPrices(JSONObject prices) {
        if (isFinishing() || isDestroyed() || webView.getUrl() == null ||
            !sameOrigin(Uri.parse(webView.getUrl()))) return;
        webView.evaluateJavascript(
            "if(typeof window.kivilcimPrices==='function')window.kivilcimPrices(" +
            JSONObject.quote(prices.toString()) + ")", null
        );
    }

    void deliverPurchase(String token, boolean interactive) {
        if (isFinishing() || isDestroyed() || webView.getUrl() == null ||
            !sameOrigin(Uri.parse(webView.getUrl()))) return;
        webView.evaluateJavascript(
            "if(typeof window.kivilcimPurchase==='function')window.kivilcimPurchase(" +
            JSONObject.quote(token) + "," + interactive + ")", null
        );
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        webView.saveState(state);
        super.onSaveInstanceState(state);
    }
}
