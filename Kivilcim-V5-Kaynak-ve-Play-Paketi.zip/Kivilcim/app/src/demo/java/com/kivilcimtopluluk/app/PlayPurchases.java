package com.kivilcimtopluluk.app;

final class PlayPurchases {
    PlayPurchases(MainActivity host) {}
    void buy(String account, String product) {}
    void restore() {}
    void close() {}
}
