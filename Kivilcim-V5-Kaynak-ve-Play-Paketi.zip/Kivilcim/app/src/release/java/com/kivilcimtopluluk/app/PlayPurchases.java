package com.kivilcimtopluluk.app;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import org.json.JSONObject;
import java.util.List;

final class PlayPurchases {
    private static final List<String> PRODUCTS = Arrays.asList(
        "kivilcim_jeton_25", "kivilcim_jeton_50", "kivilcim_jeton_75", "kivilcim_jeton_100"
    );
    private final MainActivity host;
    private final BillingClient client;
    private String waitingAccount;
    private String waitingProduct;
    private boolean connecting;
    private boolean launching;
    private boolean closed;

    PlayPurchases(MainActivity host) {
        this.host = host;
        client = BillingClient.newBuilder(host)
            .setListener((result, purchases) -> host.runOnUiThread(() -> {
                launching = false;
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    deliver(purchases, true);
                } else if (result.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
                    host.purchaseNotice("Satın alma tamamlanamadı. Tekrar dene.");
                }
            }))
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .enableAutoServiceReconnection()
            .build();
    }

    void buy(String account, String product) {
        if (launching || closed || !PRODUCTS.contains(product)) return;
        if (client.isReady()) {
            launch(account, product);
        } else {
            waitingAccount = account;
            waitingProduct = product;
            connect();
        }
    }

    void restore() {
        if (closed) return;
        if (client.isReady()) {
            queryOwned();
            queryPrices();
        } else connect();
    }

    private void connect() {
        if (connecting || closed) return;
        connecting = true;
        client.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult result) {
                host.runOnUiThread(() -> {
                    connecting = false;
                    if (closed) return;
                    String account = waitingAccount;
                    String product = waitingProduct;
                    waitingAccount = null;
                    waitingProduct = null;
                    if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        if (account != null) launch(account, product);
                        queryOwned();
                        queryPrices();
                    } else if (account != null) {
                        host.purchaseNotice("Google Play ödemelerine bağlanılamadı.");
                    }
                });
            }

            @Override
            public void onBillingServiceDisconnected() {
                host.runOnUiThread(() -> connecting = false);
            }
        });
    }

    private void launch(String account, String productId) {
        if (closed || launching) return;
        launching = true;
        QueryProductDetailsParams.Product product = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(productId)
            .setProductType(BillingClient.ProductType.INAPP)
            .build();
        client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder()
            .setProductList(Collections.singletonList(product)).build(), (result, catalog) ->
                host.runOnUiThread(() -> {
                    if (closed) return;
                    List<ProductDetails> details = catalog.getProductDetailsList();
                    if (result.getResponseCode() != BillingClient.BillingResponseCode.OK || details.isEmpty()) {
                        launching = false;
                        host.purchaseNotice("Bu jeton paketi Play Store’da şu anda kullanılamıyor.");
                        return;
                    }
                    ProductDetails item = details.get(0);
                    List<ProductDetails.OneTimePurchaseOfferDetails> offers = item.getOneTimePurchaseOfferDetailsList();
                    if (offers == null || offers.isEmpty()) {
                        launching = false;
                        host.purchaseNotice("Jeton paketinin fiyatı yüklenemedi.");
                        return;
                    }
                    BillingFlowParams.ProductDetailsParams line = BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(item).setOfferToken(offers.get(0).getOfferToken()).build();
                    BillingResult launch = client.launchBillingFlow(host, BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(Collections.singletonList(line))
                        .setObfuscatedAccountId(account).build());
                    if (launch.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                        launching = false;
                        host.purchaseNotice("Google Play satın alma ekranı açılamadı.");
                    }
                }));
    }

    private void queryPrices() {
        List<QueryProductDetailsParams.Product> products = new ArrayList<>();
        for (String id : PRODUCTS) {
            products.add(QueryProductDetailsParams.Product.newBuilder().setProductId(id)
                .setProductType(BillingClient.ProductType.INAPP).build());
        }
        client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(products).build(),
            (result, catalog) -> host.runOnUiThread(() -> {
                if (closed || result.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
                JSONObject prices = new JSONObject();
                for (ProductDetails item : catalog.getProductDetailsList()) {
                    List<ProductDetails.OneTimePurchaseOfferDetails> offers = item.getOneTimePurchaseOfferDetailsList();
                    if (offers == null || offers.isEmpty()) continue;
                    try {
                        prices.put(item.getProductId(), offers.get(0).getFormattedPrice());
                    } catch (org.json.JSONException ignored) {
                        // The catalog can still display the remaining products.
                    }
                }
                host.deliverPrices(prices);
            }));
    }

    private void queryOwned() {
        client.queryPurchasesAsync(QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP).build(), (result, purchases) -> {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    host.runOnUiThread(() -> deliver(purchases, false));
                }
            });
    }

    private void deliver(List<Purchase> purchases, boolean interactive) {
        if (closed || purchases == null) return;
        for (Purchase purchase : purchases) {
            if (Collections.disjoint(purchase.getProducts(), PRODUCTS)) continue;
            if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                host.deliverPurchase(purchase.getPurchaseToken(), interactive);
            } else if (interactive && purchase.getPurchaseState() == Purchase.PurchaseState.PENDING) {
                host.purchaseNotice("Ödeme beklemede. Jetonlar onaydan sonra yüklenir.");
            }
        }
    }

    void close() {
        closed = true;
        client.endConnection();
    }
}
