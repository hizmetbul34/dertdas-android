"""Apply scheduled chat retention and reconcile Play refunds."""
import time
import app
import chat
import play

db = app.open_db()
try:
    with db:
        db.execute("BEGIN IMMEDIATE")
        chat.prune(db, int(time.time()))
    if play.ENABLED:
        print(f"İşlenen iade: {play.reconcile(db)}")
finally:
    db.close()
