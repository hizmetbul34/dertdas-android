"""Grant or revoke moderation for an existing account from the server shell."""
import argparse
from app import handle, open_db

parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("--revoke", action="store_true")
args = parser.parse_args()
db = open_db()
try:
    with db:
        change = db.execute("UPDATE users SET moderator=? WHERE handle=?", (int(not args.revoke), handle(args.name)))
        if not change.rowcount:
            parser.error("Kullanıcı bulunamadı.")
finally:
    db.close()
