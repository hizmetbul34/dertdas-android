"""Timed two-party chat and atomic wallet operations."""
from datetime import datetime
import hashlib
import os
import re
import time
import uuid
from zoneinfo import ZoneInfo

CHAT_COST = 25
DURATION = 15 * 60
KEEP_MESSAGES = 24 * 60 * 60
KEEP_REPORTS = 30 * KEEP_MESSAGES
PRODUCTS = {f"kivilcim_jeton_{amount}": amount for amount in (25, 50, 75, 100)}
EXTENSIONS = {"15": 25, "30": 50}
ENABLED = os.environ.get("KIVILCIM_CHAT_ENABLED") == "1"
ISTANBUL = ZoneInfo("Europe/Istanbul")

SCHEMA = """
CREATE TABLE IF NOT EXISTS chat_wallet (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    balance INTEGER NOT NULL DEFAULT 0 CHECK(balance>=0), debt INTEGER NOT NULL DEFAULT 0 CHECK(debt>=0)
);
CREATE TABLE IF NOT EXISTS chat_sessions (
    id TEXT PRIMARY KEY,
    payer TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    guest TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    offered_until INTEGER NOT NULL,
    paid_accept INTEGER NOT NULL DEFAULT 0, guest_accept INTEGER NOT NULL DEFAULT 0,
    started INTEGER, ended_at INTEGER
);
CREATE TABLE IF NOT EXISTS chat_extensions (
    chat_id TEXT NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
    nonce TEXT NOT NULL,
    user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    minutes INTEGER NOT NULL CHECK(minutes IN (15,30)),
    PRIMARY KEY(chat_id,nonce)
);
CREATE INDEX IF NOT EXISTS chat_sessions_by_guest ON chat_sessions(guest,started);
CREATE TABLE IF NOT EXISTS chat_free_day (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    used_on TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_queue (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK(role IN ('payer','guest')),
    joined INTEGER NOT NULL, last_seen INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_current (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    chat_id TEXT NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS chat_messages (
    id TEXT PRIMARY KEY, chat_id TEXT NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
    author TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body TEXT NOT NULL, created INTEGER NOT NULL, nonce TEXT NOT NULL,
    UNIQUE(chat_id,author,nonce)
);
CREATE INDEX IF NOT EXISTS chat_messages_by_room ON chat_messages(chat_id,created);
CREATE INDEX IF NOT EXISTS chat_messages_by_age ON chat_messages(created);
CREATE TABLE IF NOT EXISTS chat_reports (
    id TEXT PRIMARY KEY, reporter TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    chat_id TEXT NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
    target TEXT NOT NULL, reason TEXT NOT NULL, evidence TEXT NOT NULL,
    created INTEGER NOT NULL, reviewed INTEGER, UNIQUE(reporter,chat_id,target)
);
CREATE INDEX IF NOT EXISTS chat_reports_queue ON chat_reports(reviewed,created);
CREATE TABLE IF NOT EXISTS chat_purchases (
    token_hash TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    refunded INTEGER NOT NULL DEFAULT 0,
    credited INTEGER NOT NULL, created INTEGER NOT NULL
);
"""


def account_tag(user_id):
    return hashlib.sha256(("kivilcim-play:" + user_id).encode()).hexdigest()


def prune(db, stamp):
    db.execute("DELETE FROM chat_queue WHERE last_seen<=?", (stamp - 30,))
    db.execute("DELETE FROM chat_reports WHERE created<=?", (stamp - KEEP_REPORTS,))
    db.execute("DELETE FROM chat_messages WHERE created<=?", (stamp - KEEP_MESSAGES,))
    db.execute("""DELETE FROM chat_sessions WHERE COALESCE(ended_at,started+?+60*COALESCE(
                     (SELECT SUM(minutes) FROM chat_extensions WHERE chat_id=chat_sessions.id),0),offered_until)<=?
                  AND NOT EXISTS(SELECT 1 FROM chat_reports r WHERE r.chat_id=chat_sessions.id)""",
               (DURATION, stamp - KEEP_MESSAGES))


def available(db, user):
    row = db.execute("SELECT balance,debt FROM chat_wallet WHERE user_id=?", (user,)).fetchone()
    return row["balance"] if row and not row["debt"] else 0


def free_remaining(db, user, stamp):
    local = datetime.fromtimestamp(stamp, ISTANBUL)
    day = local.date().isoformat()
    midnight = int(local.replace(hour=0, minute=0, second=0).timestamp())
    used = db.execute("""
        SELECT 1 FROM chat_free_day WHERE user_id=? AND used_on=?
        UNION ALL SELECT 1 FROM chat_sessions WHERE guest=? AND started BETWEEN ? AND ? LIMIT 1
        """, (user, day, user, midnight, stamp)).fetchone()
    return int(used is None)


def credit(db, user, quantity):
    db.execute("INSERT OR IGNORE INTO chat_wallet(user_id) VALUES(?)", (user,))
    db.execute("""UPDATE chat_wallet SET balance=balance+max(0,?-debt),debt=max(0,debt-?)
                  WHERE user_id=?""", (quantity, quantity, user))


def reclaim(db, user, quantity):
    db.execute("INSERT OR IGNORE INTO chat_wallet(user_id) VALUES(?)", (user,))
    db.execute("""UPDATE chat_wallet SET debt=debt+max(0,?-balance),balance=max(0,balance-?)
                  WHERE user_id=?""", (quantity, quantity, user))


def current(db, user):
    return db.execute("""SELECT s.*, COALESCE((SELECT SUM(minutes) FROM chat_extensions WHERE chat_id=s.id),0) AS extra_minutes
                         FROM chat_current c JOIN chat_sessions s ON s.id=c.chat_id
                         WHERE c.user_id=?""", (user,)).fetchone()


def finish(db, room, stamp):
    db.execute("UPDATE chat_sessions SET ended_at=? WHERE id=? AND ended_at IS NULL", (stamp, room["id"]))


def other(room, user):
    return room["guest"] if user == room["payer"] else room["payer"]


def status(room, stamp):
    if room["ended_at"] is not None:
        return "ended"
    if room["started"] is None:
        return "offer" if room["offered_until"] > stamp else "ended"
    return "active" if ends_at(room) > stamp else "ended"


def ends_at(room):
    return room["started"] + DURATION + room["extra_minutes"] * 60


def enforce_room(db, room, stamp):
    if room and status(room, stamp) != "ended":
        blocked = db.execute("""SELECT 1 FROM blocks WHERE (user_id=? AND target=?)
                             OR (user_id=? AND target=?)""",
                             (room["payer"], room["guest"], room["guest"], room["payer"])).fetchone()
        suspended = db.execute("SELECT 1 FROM users WHERE id IN (?,?) AND suspended=1",
                               (room["payer"], room["guest"])).fetchone()
        if blocked or suspended:
            finish(db, room, stamp)
            return dict(room, ended_at=stamp)
    return room


def arrange(db, user, stamp):
    queue = db.execute("SELECT * FROM chat_queue WHERE user_id=?", (user,)).fetchone()
    if not queue:
        return
    partner = db.execute("""
        SELECT q.user_id FROM chat_queue q JOIN users u ON u.id=q.user_id WHERE q.role<>? AND u.suspended=0
          AND NOT EXISTS(SELECT 1 FROM blocks b WHERE (b.user_id=? AND b.target=q.user_id)
                                             OR (b.target=? AND b.user_id=q.user_id))
          AND (q.role='guest' OR EXISTS(SELECT 1 FROM chat_wallet w WHERE w.user_id=q.user_id
                                       AND w.balance>=? AND w.debt=0))
        ORDER BY q.joined,q.rowid LIMIT 1""", (queue["role"], user, user, CHAT_COST)).fetchone()
    if not partner or (queue["role"] == "payer" and available(db, user) < CHAT_COST):
        return
    paired = partner["user_id"]
    payer,guest = (user, paired) if queue["role"] == "payer" else (paired, user)
    room_id = uuid.uuid4().hex
    db.execute("INSERT INTO chat_sessions(id,payer,guest,offered_until) VALUES(?,?,?,?)",
               (room_id, payer, guest, stamp + 45))
    db.executemany("INSERT OR REPLACE INTO chat_current VALUES(?,?)", [(payer, room_id), (guest, room_id)])
    db.execute("DELETE FROM chat_queue WHERE user_id IN (?,?)", (payer, guest))


def state(db, user, stamp, purchases_enabled):
    room = enforce_room(db, current(db, user), stamp)
    response = dict(balance=available(db, user), account=account_tag(user), now=stamp,
                    status="idle", purchases=purchases_enabled,
                    freeRemaining=free_remaining(db, user, stamp))
    if room:
        phase = status(room, stamp)
        payer = user == room["payer"]
        response.update(status=phase, id=room["id"], payer=payer,
                        accepted=bool(room["paid_accept"] if payer else room["guest_accept"]),
                        until=ends_at(room) if room["started"] else room["offered_until"],
                        started=room["started"] is not None)
        if room["started"] is not None:
            response["messages"] = [
                dict(id=m["id"], body=m["body"], mine=m["author"] == user)
                for m in db.execute("""SELECT * FROM (SELECT chat_messages.*,rowid AS sequence FROM chat_messages
                                     WHERE chat_id=? ORDER BY created DESC,rowid DESC LIMIT 150)
                                     ORDER BY created,sequence""", (room["id"],))
            ]
    elif db.execute("SELECT 1 FROM chat_queue WHERE user_id=?", (user,)).fetchone():
        response["status"] = "waiting"
    return response


def route(db, person, action, data, api_error, read_string, read_body, reasons, purchases_enabled):
    user, stamp = person["id"], int(time.time())
    prune(db, stamp)
    if action == "state":
        db.execute("UPDATE chat_queue SET last_seen=? WHERE user_id=?", (stamp, user))
        arrange(db, user, stamp)
        return state(db, user, stamp, purchases_enabled)
    room = enforce_room(db, current(db, user), stamp)
    phase = status(room, stamp) if room else "idle"
    if action == "join":
        role = read_string(data, "role")
        if role not in {"payer", "guest"} or data.get("terms") != "yes":
            raise api_error(400, "Katılmak için sohbet kurallarını kabul et.")
        if phase in {"offer","active"}:
            raise api_error(409, "Bekleyen bir eşleşmen veya açık sohbetin var.")
        if role == "payer" and available(db, user) < CHAT_COST:
            raise api_error(400, "Başlatmak için 25 jeton gerekli.")
        if role == "guest" and not free_remaining(db, user, stamp):
            raise api_error(409, "Bugünkü ücretsiz sohbet hakkını kullandın.")
        db.execute("DELETE FROM chat_current WHERE user_id=?", (user,))
        db.execute("INSERT OR REPLACE INTO chat_queue VALUES(?,?,?,?)", (user, role, stamp, stamp))
        arrange(db, user, stamp)
    elif action == "cancel":
        db.execute("DELETE FROM chat_queue WHERE user_id=?", (user,))
    elif not room or data.get("id") != room["id"]:
        raise api_error(404, "Sohbet bulunamadı.")
    elif action == "accept" and phase == "offer":
        column = "paid_accept" if user == room["payer"] else "guest_accept"
        db.execute(f"UPDATE chat_sessions SET {column}=1 WHERE id=?", (room["id"],))
        accepted = db.execute("SELECT paid_accept AND guest_accept FROM chat_sessions WHERE id=?",
                              (room["id"],)).fetchone()[0]
        if accepted:
            if not free_remaining(db, room["guest"], stamp):
                finish(db, room, stamp)
                return state(db, user, stamp, purchases_enabled)
            withdrawn = db.execute("""UPDATE chat_wallet SET balance=balance-? WHERE user_id=?
                                      AND balance>=? AND debt=0""", (CHAT_COST, room["payer"], CHAT_COST))
            if withdrawn.rowcount:
                day = datetime.fromtimestamp(stamp, ISTANBUL).date().isoformat()
                db.execute("""INSERT INTO chat_free_day VALUES(?,?)
                              ON CONFLICT(user_id) DO UPDATE SET used_on=excluded.used_on""",
                           (room["guest"], day))
                db.execute("UPDATE chat_sessions SET started=? WHERE id=?", (stamp, room["id"]))
            else:
                finish(db, room, stamp)
    elif action == "extend":
        minutes = read_string(data, "minutes", 2, 2)
        nonce = read_string(data, "nonce", 16, 64)
        if minutes not in EXTENSIONS or not re.fullmatch(r"[a-zA-Z0-9-]+", nonce):
            raise api_error(400, "Geçerli bir süre seç.")
        previous = db.execute("SELECT user_id,minutes FROM chat_extensions WHERE chat_id=? AND nonce=?",
                              (room["id"], nonce)).fetchone()
        if previous:
            if previous["user_id"] != user or previous["minutes"] != int(minutes):
                raise api_error(409, "Süre uzatma isteği çakıştı.")
            return state(db, user, stamp, purchases_enabled)
        if phase != "active":
            raise api_error(409, "Yalnızca süresi devam eden sohbet uzatılabilir.")
        cost = EXTENSIONS[minutes]
        charged = db.execute("""UPDATE chat_wallet SET balance=balance-? WHERE user_id=?
                              AND balance>=? AND debt=0""", (cost, user, cost))
        if not charged.rowcount:
            raise api_error(400, "Süreyi uzatmak için yeterli jetonun yok.")
        db.execute("INSERT INTO chat_extensions VALUES(?,?,?,?)", (room["id"], nonce, user, int(minutes)))
    elif action == "leave":
        finish(db, room, stamp)
    elif action == "reset" and phase == "ended":
        db.execute("DELETE FROM chat_current WHERE user_id=?", (user,))
    elif action == "message" and phase == "active":
        body = read_body(data, 1, 350)
        nonce = read_string(data, "nonce", 16, 64)
        if not re.fullmatch(r"[a-zA-Z0-9-]+", nonce):
            raise api_error(400, "Mesaj kimliği geçersiz.")
        if db.execute("SELECT count(*) FROM chat_messages WHERE author=? AND chat_id=? AND created>?",
                      (user, room["id"], stamp - 10)).fetchone()[0] >= 8:
            raise api_error(429, "Mesaj göndermeden birkaç saniye bekle.")
        db.execute("""INSERT INTO chat_messages VALUES(?,?,?,?,?,?)
                      ON CONFLICT(chat_id,author,nonce) DO NOTHING""",
                   (uuid.uuid4().hex, room["id"], user, body, stamp, nonce))
    elif action == "block":
        db.execute("INSERT OR IGNORE INTO blocks VALUES(?,?)", (user, other(room, user)))
        finish(db, room, stamp)
    elif action == "report":
        reason = read_string(data, "reason")
        target = read_string(data, "target")
        if reason not in reasons:
            raise api_error(400, "Bir bildirim nedeni seç.")
        subject = other(room,user)
        if target == "user":
            sample = db.execute("""SELECT body FROM chat_messages WHERE chat_id=? AND author=?
                                ORDER BY created DESC,rowid DESC LIMIT 5""", (room["id"], subject))
            evidence = "\n".join(r[0] for r in reversed(list(sample)))
        else:
            row = db.execute("SELECT body FROM chat_messages WHERE id=? AND chat_id=? AND author=?",
                             (target, room["id"], subject)).fetchone()
            if not row:
                raise api_error(404, "Mesaj bulunamadı.")
            evidence = row[0]
        db.execute("""INSERT INTO chat_reports(id,reporter,subject,chat_id,target,reason,evidence,created)
                      VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(reporter,chat_id,target) DO NOTHING""",
                   (uuid.uuid4().hex,user,subject,room["id"],target,reason,evidence,stamp))
    else:
        raise api_error(409, "Sohbet durumu değişti. Ekranı yenile.")
    return state(db, user, stamp, purchases_enabled)


def moderate(db, person, action, data, api_error, read_string):
    if not person["moderator"]:
        raise api_error(403, "Moderasyon erişimi gerekli.")
    stamp = int(time.time())
    prune(db, stamp)
    if action == "chat-reports":
        return [dict(r) for r in db.execute("""SELECT id,reason,evidence FROM chat_reports
                  WHERE reviewed IS NULL ORDER BY (reason='Çocuk güvenliği') DESC,created LIMIT 50""")]
    row = db.execute("SELECT * FROM chat_reports WHERE id=? AND reviewed IS NULL",
                     (read_string(data, "id"),)).fetchone()
    if not row:
        raise api_error(404, "Bildirim artık beklemiyor.")
    decision = read_string(data,"decision")
    if decision == "end":
        db.execute("UPDATE chat_sessions SET ended_at=COALESCE(ended_at,?) WHERE id=?", (stamp,row["chat_id"]))
        if row["target"] != "user":
            db.execute("DELETE FROM chat_messages WHERE id=?", (row["target"],))
    elif decision == "suspend":
        if not db.execute("UPDATE users SET suspended=1 WHERE id=? AND moderator=0", (row["subject"],)).rowcount:
            raise api_error(400, "Bu hesap askıya alınamaz.")
        db.execute("DELETE FROM sessions WHERE user_id=?", (row["subject"],))
        db.execute("DELETE FROM chat_queue WHERE user_id=?", (row["subject"],))
        db.execute("UPDATE chat_sessions SET ended_at=COALESCE(ended_at,?) WHERE payer=? OR guest=?",
                   (stamp,row["subject"],row["subject"]))
    elif decision != "dismiss":
        raise api_error(400, "Geçersiz moderasyon kararı.")
    db.execute("UPDATE chat_reports SET reviewed=? WHERE id=?", (stamp,row["id"]))
    return True
