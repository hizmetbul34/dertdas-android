"""Kıvılcım WSGI service. Run behind an HTTPS reverse proxy."""
import datetime as dt
import hashlib
import hmac
import html
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import time
import unicodedata
from http.cookies import SimpleCookie
from zoneinfo import ZoneInfo

import chat
import play

ASSETS = Path(__file__).resolve().parents[1] / "app/src/main/assets"
DB = os.environ.get("KIVILCIM_DB", str(Path(__file__).with_name("kivilcim.sqlite3")))
ORIGIN = os.environ.get("KIVILCIM_ORIGIN", "http://127.0.0.1:8095").rstrip("/")
LOCAL = ORIGIN.startswith(("http://127.0.0.1:", "http://localhost:"))
CONTACT = os.environ.get("KIVILCIM_CONTACT", "")
OWNER = os.environ.get("KIVILCIM_OPERATOR", "")
if not LOCAL and (not ORIGIN.startswith("https://") or not OWNER or not re.fullmatch(r"[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}", CONTACT)):
    raise RuntimeError("Set HTTPS KIVILCIM_ORIGIN, KIVILCIM_OPERATOR and KIVILCIM_CONTACT.")

COOKIE = "kivilcim_session" if LOCAL else "__Host-kivilcim_session"
CLUBS = {"gunun", "sehir", "kultur", "hobi", "mola"}
REASONS = {"Taciz veya zorbalık", "Nefret veya tehdit", "Çocuk güvenliği", "Cinsel içerik",
           "Kişisel bilgi paylaşımı", "Spam veya dolandırıcılık", "Diğer"}
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, handle TEXT NOT NULL UNIQUE,
    salt BLOB NOT NULL, password BLOB NOT NULL, accepted INTEGER NOT NULL,
    moderator INTEGER NOT NULL DEFAULT 0, suspended INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users ON DELETE CASCADE,
    expires INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS posts (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users ON DELETE CASCADE,
    club TEXT NOT NULL, body TEXT NOT NULL, created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS replies (
    id TEXT PRIMARY KEY, post_id TEXT NOT NULL REFERENCES posts ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users ON DELETE CASCADE, body TEXT NOT NULL, created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS likes (
    user_id TEXT NOT NULL REFERENCES users ON DELETE CASCADE,
    post_id TEXT NOT NULL REFERENCES posts ON DELETE CASCADE, PRIMARY KEY(user_id, post_id)
);
CREATE TABLE IF NOT EXISTS bookmarks (
    user_id TEXT NOT NULL REFERENCES users ON DELETE CASCADE,
    post_id TEXT NOT NULL REFERENCES posts ON DELETE CASCADE, PRIMARY KEY(user_id, post_id)
);
CREATE TABLE IF NOT EXISTS blocks (
    user_id TEXT NOT NULL REFERENCES users ON DELETE CASCADE,
    target TEXT NOT NULL REFERENCES users ON DELETE CASCADE, PRIMARY KEY(user_id, target)
);
CREATE TABLE IF NOT EXISTS reports (
    id TEXT PRIMARY KEY, reporter TEXT NOT NULL REFERENCES users ON DELETE CASCADE,
    target_user TEXT NOT NULL REFERENCES users ON DELETE CASCADE,
    post_id TEXT REFERENCES posts ON DELETE CASCADE, reply_id TEXT REFERENCES replies ON DELETE CASCADE,
    type TEXT NOT NULL, target TEXT NOT NULL, reason TEXT NOT NULL, created INTEGER NOT NULL,
    reviewed INTEGER, UNIQUE(reporter, type, target)
);
CREATE TABLE IF NOT EXISTS rate (
    bucket TEXT NOT NULL, slot INTEGER NOT NULL, count INTEGER NOT NULL,
    PRIMARY KEY(bucket, slot)
);
CREATE INDEX IF NOT EXISTS posts_created ON posts(created DESC);
CREATE INDEX IF NOT EXISTS replies_post ON replies(post_id, created);
CREATE INDEX IF NOT EXISTS likes_post ON likes(post_id);
CREATE INDEX IF NOT EXISTS reports_queue ON reports(reviewed, created);
CREATE INDEX IF NOT EXISTS sessions_expires ON sessions(expires);
"""


class ApiError(Exception):
    def __init__(self, status, message):
        self.status = status
        self.message = message


def open_db():
    db = sqlite3.connect(DB, timeout=8)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    return db


def init():
    with open_db() as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript(SCHEMA + chat.SCHEMA)
    db.close()


def now():
    return int(time.time())


def identity():
    return secrets.token_hex(16)


def secret_hash(value):
    return hashlib.sha256(value.encode()).hexdigest()


def password_hash(password, salt):
    return hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)


def string(data, key, minimum=1, maximum=128, strip=True):
    value = data.get(key)
    if not isinstance(value, str):
        raise ApiError(400, "Gerekli alanları doldur.")
    value = value.strip() if strip else value
    if not minimum <= len(value) <= maximum or any(0xD800 <= ord(c) <= 0xDFFF for c in value):
        raise ApiError(400, "Alan uzunluğu veya biçimi geçersiz.")
    return value


def handle(name):
    return unicodedata.normalize("NFKC", name).casefold()


def text_body(data, minimum, maximum):
    value = string(data, "body", minimum, maximum)
    if any(unicodedata.category(c).startswith("C") and c not in "\n\r\t" for c in value):
        raise ApiError(400, "Metinde desteklenmeyen karakterler var.")
    return value


def rate(bucket, limit):
    # A separate committed connection retains limits on invalid requests, too.
    slot = now() // 600
    db = open_db()
    try:
        with db:
            db.execute("DELETE FROM rate WHERE slot<?", (slot - 2,))
            count = db.execute(
                """INSERT INTO rate VALUES(?,?,1) ON CONFLICT(bucket,slot)
                   DO UPDATE SET count=count+1 RETURNING count""", (bucket, slot)
            ).fetchone()[0]
    finally:
        db.close()
    if count > limit:
        raise ApiError(429, "Çok fazla deneme. Birkaç dakika sonra tekrar dene.")


def can_see(db, viewer, author):
    return not db.execute(
        """SELECT 1 FROM blocks WHERE (user_id=? AND target=?) OR (target=? AND user_id=?)""",
        (viewer, author, viewer, author)
    ).fetchone()


def user_for(db, env):
    cookies = SimpleCookie()
    try:
        cookies.load(env.get("HTTP_COOKIE", ""))
    except Exception:
        return None, ""
    morsel = cookies.get(COOKIE)
    if not morsel or not re.fullmatch(r"[A-Za-z0-9_-]{43}", morsel.value):
        return None, ""
    token = secret_hash(morsel.value)
    user = db.execute(
        """SELECT users.* FROM sessions JOIN users ON users.id=sessions.user_id
           WHERE token=? AND expires>? AND suspended=0""", (token, now())
    ).fetchone()
    return user, token


def cookie(value, age):
    return ("Set-Cookie", f"{COOKIE}={value}; Path=/; HttpOnly; SameSite=Strict; Max-Age={age}"
            + ("" if LOCAL else "; Secure"))


def make_session(db, user, old_token):
    token = secrets.token_urlsafe(32)
    age = 60 * 60 * 24 * 30
    db.execute("DELETE FROM sessions WHERE token=? OR expires<=?", (old_token, now()))
    db.execute("INSERT INTO sessions VALUES(?,?,?)", (secret_hash(token), user, now() + age))
    return cookie(token, age)


def require_member(user):
    if not user:
        raise ApiError(401, "Bu işlem için giriş yap.")


def get_post(db, viewer, post_id):
    row = db.execute(
        """SELECT p.*,u.name FROM posts p JOIN users u ON u.id=p.user_id
           WHERE p.id=? AND u.suspended=0""", (post_id,)
    ).fetchone()
    if not row or not can_see(db, viewer, row["user_id"]):
        raise ApiError(404, "Paylaşım bulunamadı.")
    return row


def serialize_posts(db, viewer, post_id=None):
    query = """
    WITH hidden(id) AS (
      SELECT target FROM blocks WHERE user_id=?
      UNION SELECT user_id FROM blocks WHERE target=?
    )
    SELECT p.*, u.name,
      EXISTS(SELECT 1 FROM likes l WHERE l.post_id=p.id AND l.user_id=?) AS liked,
      EXISTS(SELECT 1 FROM bookmarks b WHERE b.post_id=p.id AND b.user_id=?) AS saved,
      (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id AND l.user_id NOT IN hidden) AS score,
      (SELECT COUNT(*) FROM replies r JOIN users ru ON ru.id=r.user_id
       WHERE r.post_id=p.id AND ru.suspended=0 AND r.user_id NOT IN hidden) AS reply_count
    FROM posts p JOIN users u ON u.id=p.user_id
    WHERE u.suspended=0 AND p.user_id NOT IN hidden
    """
    args = [viewer] * 4
    if post_id is not None:
        query += " AND p.id=?"
        args.append(post_id)
    else:
        query += """ AND (p.id IN (SELECT recent.id FROM posts recent JOIN users author ON author.id=recent.user_id
                                   WHERE author.suspended=0 AND recent.user_id NOT IN hidden
                                   ORDER BY recent.created DESC, recent.rowid DESC LIMIT 120)
                          OR EXISTS(SELECT 1 FROM bookmarks WHERE post_id=p.id AND user_id=?))
                    ORDER BY p.created DESC, p.rowid DESC LIMIT 500"""
        args.append(viewer)
    return [
        dict(id=p["id"], author=p["name"], authorId=p["user_id"], mine=p["user_id"] == viewer,
             club=p["club"], body=p["body"], score=p["score"], replyCount=p["reply_count"],
             liked=bool(p["liked"]), saved=bool(p["saved"]))
        for p in db.execute(query, args)
    ]


def report(db, user, data):
    kind = string(data, "type")
    target = string(data, "target")
    reason = string(data, "reason")
    if reason not in REASONS:
        raise ApiError(400, "Bir bildirim nedeni seç.")
    post_id = reply_id = None
    if kind == "post":
        post_id = target
        author = get_post(db, user, post_id)["user_id"]
    elif kind == "reply":
        reply_id = target
        row = db.execute(
            """SELECT r.* FROM replies r JOIN users u ON r.user_id=u.id WHERE r.id=? AND u.suspended=0""",
            (reply_id,)
        ).fetchone()
        if not row:
            raise ApiError(404, "Yorum bulunamadı.")
        post_id, author = row["post_id"], row["user_id"]
        get_post(db, user, post_id)
    elif kind == "user":
        author = target
        if not db.execute("SELECT 1 FROM users WHERE id=? AND suspended=0", (author,)).fetchone():
            raise ApiError(404, "Kullanıcı bulunamadı.")
    else:
        raise ApiError(400, "Geçersiz bildirim.")
    if author == user or not can_see(db, user, author):
        raise ApiError(400, "Bu bildirim gönderilemedi.")
    db.execute(
        """INSERT INTO reports(id,reporter,target_user,post_id,reply_id,type,target,reason,created)
           VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(reporter,type,target) DO NOTHING""",
        (identity(), user, author, post_id, reply_id, kind, target, reason, now())
    )


def moderation(db, person, path, data):
    if not person["moderator"]:
        raise ApiError(403, "Moderasyon erişimi gerekli.")
    if path == "/reports":
        return [dict(row) for row in db.execute(
            """SELECT r.id,r.reason,r.type, CASE r.type WHEN 'post' THEN p.body
               WHEN 'reply' THEN c.body ELSE u.name END as content
               FROM reports r LEFT JOIN posts p ON p.id=r.post_id
               LEFT JOIN replies c ON c.id=r.reply_id JOIN users u ON u.id=r.target_user
               WHERE r.reviewed IS NULL ORDER BY (r.reason='Çocuk güvenliği') DESC,r.created LIMIT 50"""
        )]
    row = db.execute("SELECT * FROM reports WHERE id=? AND reviewed IS NULL", (string(data, "id"),)).fetchone()
    if not row:
        raise ApiError(404, "Bildirim artık beklemiyor.")
    decision = string(data, "decision")
    if decision == "dismiss":
        db.execute("UPDATE reports SET reviewed=? WHERE id=?", (now(), row["id"]))
    elif decision == "remove" and row["type"] == "post":
        db.execute("DELETE FROM posts WHERE id=?", (row["post_id"],))
    elif decision == "remove" and row["type"] == "reply":
        db.execute("DELETE FROM replies WHERE id=?", (row["reply_id"],))
    elif decision == "suspend" and row["type"] == "user":
        result = db.execute("UPDATE users SET suspended=1 WHERE id=? AND moderator=0", (row["target_user"],))
        if not result.rowcount:
            raise ApiError(400, "Bu hesap askıya alınamaz.")
        db.execute("DELETE FROM sessions WHERE user_id=?", (row["target_user"],))
        db.execute("UPDATE reports SET reviewed=? WHERE target_user=?", (now(), row["target_user"]))
    else:
        raise ApiError(400, "Geçersiz moderasyon kararı.")
    return True


def route(db, env, path, data, headers):
    person, token = user_for(db, env)
    viewer = person["id"] if person else ""
    method = env["REQUEST_METHOD"]
    if method == "GET":
        if path == "/me":
            return dict(name=person["name"], moderator=bool(person["moderator"])) if person else None
        if path == "/feed":
            return serialize_posts(db, viewer)
        if path.startswith("/post/"):
            posts = serialize_posts(db, viewer, path[len("/post/"):])
            if not posts:
                raise ApiError(404, "Paylaşım bulunamadı.")
            posts[0]["replies"] = [
                dict(id=r["id"], author=r["name"], authorId=r["user_id"], mine=r["user_id"] == viewer, body=r["body"])
                for r in db.execute(
                    """SELECT r.*,u.name FROM replies r JOIN users u ON u.id=r.user_id WHERE r.post_id=?
                       AND u.suspended=0 AND r.user_id NOT IN (SELECT target FROM blocks WHERE user_id=?
                       UNION SELECT user_id FROM blocks WHERE target=?) ORDER BY r.created DESC,r.rowid DESC LIMIT 150""",
                    (posts[0]["id"], viewer, viewer)
                )
            ]
            return posts[0]
        if path == "/blocks":
            require_member(person)
            return [dict(row) for row in db.execute(
                "SELECT u.id,u.name FROM blocks b JOIN users u ON u.id=b.target WHERE b.user_id=?", (viewer,)
            )]
        if path == "/reports":
            require_member(person)
            return moderation(db, person, path, data)
        if path == "/chat-reports":
            require_member(person)
            db.execute("BEGIN IMMEDIATE")
            return chat.moderate(db, person, "chat-reports", data, ApiError, string)
        raise ApiError(404, "Sayfa bulunamadı.")

    if path in ("/signup", "/login"):
        name = string(data, "name", 3, 24)
        password = string(data, "password", 10, 128, strip=False)
        normalized = handle(name)
        # Do not store raw IP addresses in the rate table.
        address = env.get("REMOTE_ADDR", "")
        rate(("signup:" if path == "/signup" else "login:") + secret_hash(address), 22)
        if path == "/signup":
            try:
                birth = dt.date.fromisoformat(string(data, "birth", 10, 10))
            except ValueError:
                raise ApiError(400, "Doğum tarihini kontrol et.")
            today = dt.datetime.now(ZoneInfo("Europe/Istanbul")).date()
            age = today.year - birth.year - ((today.month, today.day) < (birth.month, birth.day))
            if birth.year < 1900 or age < 18 or data.get("adult") != "yes" or data.get("terms") != "yes":
                raise ApiError(400, "Kıvılcım 18 yaş ve üzeri içindir. Kuralları kabul etmen gerekir.")
            if not re.fullmatch(r"[\w-]{3,24}", name) or not re.fullmatch(r"[\w-]{3,48}", normalized):
                raise ApiError(400, "Kullanıcı adı biçimini kontrol et.")
            if db.execute("SELECT 1 FROM users WHERE handle=?", (normalized,)).fetchone():
                raise ApiError(409, "Bu kullanıcı adı kullanımda.")
            viewer, salt = identity(), secrets.token_bytes(16)
            hashed = password_hash(password, salt)
            try:
                db.execute("INSERT INTO users(id,name,handle,salt,password,accepted) VALUES(?,?,?,?,?,?)",
                           (viewer, name, normalized, salt, hashed, now()))
            except sqlite3.IntegrityError:
                raise ApiError(409, "Bu kullanıcı adı kullanımda.")
        else:
            rate("handle:" + secret_hash(normalized), 12)
            row = db.execute("SELECT * FROM users WHERE handle=?", (normalized,)).fetchone()
            digest = password_hash(password, row["salt"] if row else bytes(16))
            if not row or not hmac.compare_digest(digest, row["password"]) or row["suspended"]:
                raise ApiError(401, "Kullanıcı adı veya şifre doğrulanamadı.")
            viewer = row["id"]
        headers.append(make_session(db, viewer, token))
        return True
    if path == "/logout":
        if person:
            db.execute("DELETE FROM chat_queue WHERE user_id=?", (viewer,))
        db.execute("DELETE FROM sessions WHERE token=?", (token,))
        headers.append(cookie("", 0))
        return True

    require_member(person)
    if path.startswith("/chat/"):
        if not chat.ENABLED:
            raise ApiError(503, "Anonim sohbet henüz açılmadı.")
        action = path[len("/chat/"):]
        if action == "purchase":
            rate("play:" + viewer, 50)
            return play.verify_and_grant(db, viewer, string(data, "token", 8, 4096), ApiError)
        rate(("chat-poll:" if action == "state" else "chat-write:") + viewer, 650 if action == "state" else 225)
        db.execute("BEGIN IMMEDIATE")
        return chat.route(db, person, action, data, ApiError, string, text_body, REASONS, play.ENABLED)

    rate("write:" + viewer, 55)
    db.execute("BEGIN IMMEDIATE")
    if path == "/delete-account":
        password = string(data, "password", 10, 128, strip=False)
        if data.get("confirm") != "yes" or not hmac.compare_digest(password_hash(password, person["salt"]), person["password"]):
            raise ApiError(400, "Şifre ve silme onayı gerekli.")
        db.execute("DELETE FROM users WHERE id=?", (viewer,))
        headers.append(cookie("", 0))
    elif path == "/post":
        club = string(data, "club")
        if club not in CLUBS:
            raise ApiError(400, "Geçerli bir kulüp seç.")
        db.execute("INSERT INTO posts VALUES(?,?,?,?,?)", (identity(), viewer, club, text_body(data, 3, 500), now()))
    elif path == "/reply":
        post_id = get_post(db, viewer, string(data, "id"))["id"]
        db.execute("INSERT INTO replies VALUES(?,?,?,?,?)", (identity(), post_id, viewer, text_body(data, 2, 350), now()))
    elif path in ("/save", "/like"):
        post_id = get_post(db, viewer, string(data, "id"))["id"]
        table = "bookmarks" if path == "/save" else "likes"
        deleted = db.execute(f"DELETE FROM {table} WHERE user_id=? AND post_id=?", (viewer, post_id))
        if not deleted.rowcount:
            if table == "bookmarks" and db.execute("SELECT count(*) FROM bookmarks WHERE user_id=?", (viewer,)).fetchone()[0] >= 300:
                raise ApiError(400, "En fazla 300 paylaşım kaydedebilirsin.")
            db.execute(f"INSERT INTO {table} VALUES(?,?)", (viewer, post_id))
    elif path in ("/delete-post", "/delete-reply"):
        table = "posts" if path == "/delete-post" else "replies"
        if not db.execute(f"DELETE FROM {table} WHERE id=? AND user_id=?", (string(data, "id"), viewer)).rowcount:
            raise ApiError(404, "İçerik bulunamadı.")
    elif path in ("/block", "/unblock"):
        target = string(data, "target")
        if path == "/block":
            if target == viewer or not db.execute("SELECT 1 FROM users WHERE id=?", (target,)).fetchone():
                raise ApiError(400, "Bu kullanıcı engellenemedi.")
            db.execute("INSERT OR IGNORE INTO blocks VALUES(?,?)", (viewer, target))
        else:
            db.execute("DELETE FROM blocks WHERE user_id=? AND target=?", (viewer, target))
    elif path == "/report":
        report(db, viewer, data)
    elif path == "/moderate":
        return moderation(db, person, path, data)
    elif path == "/chat-moderate":
        return chat.moderate(db, person, "chat-moderate", data, ApiError, string)
    else:
        raise ApiError(404, "İşlem bulunamadı.")
    return True


def rules_page(path):
    contact = (f'<a href="mailto:{html.escape(CONTACT, quote=True)}">{html.escape(CONTACT)}</a>'
               if CONTACT else "Yerel test ortamı")
    operator = html.escape(OWNER) or "Kıvılcım yerel test ortamı"
    if path == "/kurallar":
        title = "Topluluk ve kullanım kuralları"
        content = f"""<p>Kıvılcım 18 yaş ve üzeri kullanıcılar için bir sohbet topluluğudur. Paylaşımlarını herkese açık olarak yayınlarsın. Gönderi paylaşmadan önce yayınlama hakkına sahip olduğundan emin ol.</p>
        <p>Taciz, zorbalık, nefret söylemi, şiddet tehdidi, açık cinsel içerik, çocukların istismarı ve sömürüsü, kişisel bilgilerin izinsiz ifşası, dolandırıcılık, spam ve yasa dışı içerik yasaktır. Başka kullanıcıların kimliğine bürünme ve askıya alma kararlarını aşma girişimleri de yasaktır.</p>
        <p>Gönderi ve yorum seçenekleriyle içeriği veya kullanıcıyı bildirebilir ve kullanıcıyı engelleyebilirsin. Moderasyon, bildirilen içeriği inceleyebilir, kaldırabilir veya hesabı askıya alabilir. İtiraz ve destek için {contact} adresini kullan.</p>
        <p>Anonim Sohbet 18 yaş ve üzeri hesaplara açıktır. Karşı taraf profil adını görmez. Tehdit, cinsel taciz ve istismar, şantaj, kişisel bilgi paylaşımı, spam ve dolandırıcılık yasaktır. Bir mesajı veya kişiyi bildirebilir, sohbeti bitirebilir ya da kullanıcıyı engelleyebilirsin. Eşleşme iki taraf da kabul ettiğinde başlar ve başlatanın bakiyesinden 25 jeton düşer. Sohbet 15 dakika olarak başlar. Sohbet sürerken kendi bakiyenden 25 jetonla 15 dakika veya 50 jetonla 30 dakika ekleyebilirsin; ek süre iki tarafta da geçerli olur. Gelen bir eşleşmeye günde 1 kez ücretsiz katılabilirsin. Hak sohbet başlayınca kullanılır ve Türkiye saatiyle 00.00’da yenilenir. Sohbet başladıktan sonra erken çıkışta başlangıç ve süre uzatma ücretleri geri yüklenmez. Satın alınan jetonlar yalnızca Kıvılcım içinde kullanılır.</p>
        <p><a href="/cocuk-guvenligi">Çocuk güvenliği standartları</a></p>"""
    elif path == "/gizlilik":
        title = "Gizlilik ve hesap silme"
        content = f"""<p>Uygulama işletmecisi {operator}. İletişim adresi {contact}.</p>
        <p>Kullanıcı adını, şifrenin tuzlanmış özetini, koşulları kabul zamanını, gönderi ve yorumlarını, desteklerini, yer imlerini, engellemeleri ve bildirimleri hesap ve topluluk hizmetini sağlayabilmek için tutarız. Doğum tarihi, yaş kontrolü sırasında işlenir ve veritabanına yazılmaz. Oturum için güvenlik çerezi kullanılır. Kötüye kullanımı sınırlamak için kısa süreli istek sayaçları tutulur.</p>
        <p>Gönderiler, yorumlar ve görünen kullanıcı adları herkese açıktır. Bildirimler moderasyon yetkisi olan kişilerce işlenir. Uygulamada reklam, konum izni veya reklam amaçlı izleme bulunmaz. Veriler satılmaz. Yetkili kurumlara uygulanabilir yasal yükümlülük halinde veri aktarılabilir.</p>
        <p>Anonim sohbette görünen kimlik takma addır. Hizmet eşleştirme, engelleme ve moderasyon için iki hesabın kimliğini işler. Ücretsiz katılım hakkını yönetmek için hakkın son kullanıldığı gün saklanır. Mesajlar 24 saat içinde temizlenir. Bildirime eklenen mesaj örnekleri moderasyon amacıyla en fazla 30 gün saklanır. Jeton satın alımını doğrulamak ve iadeyi işlemek için Google Play'e uygulamaya özel hesap tanıtıcısı ve satın alma belirteci iletilir. Yeniden kullanımı önlemek için satın alma belirtecinin özeti, hesap silindiğinde kullanıcı bağlantısı kaldırılarak korunur.</p>
        <p>Hesabı sildiğinde profilin, oturumların, gönderilerin, yorumların ve hesapla ilişkili etkileşimler veritabanından kaldırılır. Destek, veri erişimi ve gizlilik talepleri için {contact} adresine başvurabilirsin.</p>
        <p><a href="/hesap-silme">Web üzerinden hesabını ve verilerini sil</a>.</p>"""
    elif path == "/cocuk-guvenligi":
        title = "Çocuk güvenliği standartları"
        content = f"""<p>Kıvılcım, çocukların cinsel istismarı ve sömürüsüne (CSAE) ve çocuk cinsel istismarı materyaline (CSAM) sıfır tolerans uygular. Çocukları cinsel amaçla kandırma, şantaj, istismar materyali isteme, üretme, paylaşma, barındırma veya buna yönlendirme kesinlikle yasaktır.</p>
        <p>İçerik veya kullanıcı menüsünden Bildir seçeneğini açıp Çocuk güvenliği nedenini seç. İçeriği kopyalama, indirme veya tekrar paylaşma. Uygulama dışında bildirim göndermek için {contact} adresini kullan. Bu adres çocuk güvenliği irtibat noktasıdır.</p>
        <p>Çocuk güvenliği bildirimlerine öncelik verilir. Tespit edilen ihlaller kaldırılır, ilgili hesaplara işlem uygulanır ve doğrulanan materyal, yürürlükteki yükümlülükler uyarınca yetkili ulusal veya bölgesel kuruma bildirilir.</p>"""
    else:
        title = "Hesabını ve verilerini sil"
        content = f"""<p>Kıvılcım hesabına ait kullanıcı adı ve şifreyi kullan. Bu işlem profili, içerikleri ve veritabanındaki ilişkili hesap verilerini kalıcı olarak siler.</p>
        <form id="remove-account"><label>Kullanıcı adı<input name="name" autocomplete="username" minlength="3" maxlength="24" required></label>
        <label>Şifre<input name="password" type="password" autocomplete="current-password" minlength="10" maxlength="128" required></label>
        <label class="check"><input name="confirm" type="checkbox" value="yes" required><span>Hesabımı ve verilerimi kalıcı olarak silmek istiyorum.</span></label>
        <p id="status" role="status"></p><button class="danger" type="submit">Hesabı sil</button></form>
        <p>Hesabına erişemiyorsan {contact} adresinden silme talebi gönderebilirsin.</p><script src="/delete.js" defer></script>"""
    return f"""<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>{title} · Kıvılcım</title><link rel="stylesheet" href="/style.css"><header class="top"><a class="brand" href="/"><span>✦</span> kıvılcım<span class="dot">.</span></a></header>
    <main class="stack"><h1>{title}</h1>{content}</main></html>"""


def application(env, start_response):
    path = env.get("PATH_INFO", "/")
    method = env["REQUEST_METHOD"]
    headers = [
        ("X-Content-Type-Options", "nosniff"),
        ("Referrer-Policy", "no-referrer"),
        ("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'"),
        ("Permissions-Policy", "camera=(), microphone=(), geolocation=()"),
        ("Cache-Control", "no-store"),
    ]
    if not LOCAL:
        headers.append(("Strict-Transport-Security", "max-age=31536000"))
    status, kind = 200, "application/json; charset=utf-8"
    try:
        if path.startswith("/api/"):
            if method not in {"GET", "POST"}:
                raise ApiError(405, "Bu yöntem desteklenmiyor.")
            data = {}
            if method == "POST":
                if env.get("HTTP_ORIGIN") != ORIGIN or env.get("CONTENT_TYPE", "").split(";")[0] != "application/json":
                    raise ApiError(403, "İsteğin kaynağı doğrulanamadı.")
                try:
                    length = int(env.get("CONTENT_LENGTH") or 0)
                    if not 0 < length <= 8192:
                        raise ValueError()
                    data = json.loads(env["wsgi.input"].read(length))
                    if not isinstance(data, dict):
                        raise ValueError()
                except (ValueError, RecursionError):
                    raise ApiError(400, "İstek içeriği geçersiz.")
            db = open_db()
            try:
                with db:
                    result = route(db, env, path[4:], data, headers)
            finally:
                db.close()
            body = json.dumps({"result": result}, ensure_ascii=False).encode()
        elif method != "GET":
            raise ApiError(405, "Bu yöntem desteklenmiyor.")
        elif path in {"/kurallar", "/gizlilik", "/cocuk-guvenligi", "/hesap-silme"}:
            kind = "text/html; charset=utf-8"
            body = rules_page(path).encode()
        elif path in {"/", "/index.html", "/style.css", "/app.js", "/chat.js", "/delete.js"}:
            assets = {"/": ("index.html", "text/html"), "/index.html": ("index.html", "text/html"),
                      "/style.css": ("style.css", "text/css"), "/app.js": ("app.js", "text/javascript"),
                      "/chat.js": ("chat.js", "text/javascript"), "/delete.js": ("delete.js", "text/javascript")}
            file, mime = assets[path]
            kind = mime + "; charset=utf-8"
            body = (ASSETS / file).read_bytes()
        elif path == "/health":
            body = b'{"ok":true}'
        else:
            raise ApiError(404, "Sayfa bulunamadı.")
    except ApiError as error:
        status = error.status
        headers = [x for x in headers if x[0] != "Set-Cookie"]
        body = json.dumps({"error": error.message}, ensure_ascii=False).encode()
    except sqlite3.OperationalError as error:
        print("Database operation failed:", error, file=env["wsgi.errors"])
        status = 503
        headers = [x for x in headers if x[0] != "Set-Cookie"]
        body = json.dumps({"error": "Hizmet geçici olarak meşgul. Tekrar dene."}, ensure_ascii=False).encode()
    labels = {200: "OK", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden",
              404: "Not Found", 405: "Method Not Allowed", 409: "Conflict",
              429: "Too Many Requests", 503: "Service Unavailable"}
    start_response(f"{status} {labels[status]}", headers + [("Content-Type", kind), ("Content-Length", str(len(body)))])
    return [body]


init()

if __name__ == "__main__":
    from wsgiref.simple_server import make_server
    with make_server("127.0.0.1", int(os.environ.get("PORT", "8095")), application) as server:
        server.serve_forever()
