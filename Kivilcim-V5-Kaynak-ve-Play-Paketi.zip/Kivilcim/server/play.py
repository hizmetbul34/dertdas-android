"""Server-side Google Play verification and wallet reconciliation."""
import hashlib
import os
import threading
import time
from urllib.parse import quote

import chat

PACKAGE = "com.kivilcimtopluluk.app"
SCOPE = "https://www.googleapis.com/auth/androidpublisher"
BASE = f"https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{PACKAGE}"
ENABLED = chat.ENABLED and bool(os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"))
_client = None
_guard = threading.Lock()


def google_request(method, path, params=None):
    global _client
    import google.auth
    from google.auth.transport.requests import AuthorizedSession

    with _guard:
        if _client is None:
            credentials, _ = google.auth.default(scopes=[SCOPE])
            _client = AuthorizedSession(credentials)
        return _client.request(method, BASE + path, params=params, timeout=8)


def verify_and_grant(db, user, token, api_error):
    if not ENABLED:
        raise api_error(503, "Google Play jeton satışı henüz açılmadı.")
    key = hashlib.sha256(token.encode()).hexdigest()
    safe_token = quote(token, safe="")
    try:
        result = google_request("GET", "/purchases/productsv2/tokens/" + safe_token)
    except Exception:
        raise api_error(503, "Google Play doğrulamasına erişilemedi. Daha sonra tekrar dene.")
    if result.status_code in {400, 404}:
        raise api_error(400, "Google Play bu satın alımı doğrulamadı.")
    if result.status_code != 200:
        raise api_error(503, "Google Play doğrulaması şu anda kullanılamıyor.")
    payload = result.json()
    if payload.get("obfuscatedExternalAccountId") != chat.account_tag(user):
        raise api_error(403, "Satın alım başka bir Kıvılcım hesabına ait.")
    status = payload.get("purchaseStateContext", {}).get("purchaseState")
    if status == "PENDING":
        return {"pending": True}
    lines = payload.get("productLineItem", [])
    product = lines[0].get("productId") if len(lines) == 1 else None
    if status != "PURCHASED" or product not in chat.PRODUCTS:
        raise api_error(400, "Bu ürün veya satın alım durumu geçersiz.")
    offer = lines[0].get("productOfferDetails") or {}
    if offer.get("quantity", 1) != 1:
        raise api_error(400, "Bu paket yalnızca tekli satın alımı destekler.")
    consumed = offer.get("consumptionState") == "CONSUMPTION_STATE_CONSUMED"
    with db:
        db.execute("BEGIN IMMEDIATE")
        current = db.execute("SELECT suspended FROM users WHERE id=?", (user,)).fetchone()
        if not current or current["suspended"]:
            raise api_error(401, "Bu hesap satın alım alamıyor.")
        recorded = db.execute("SELECT user_id,refunded FROM chat_purchases WHERE token_hash=?", (key,)).fetchone()
        if recorded is not None:
            if recorded["user_id"] != user or recorded["refunded"]:
                raise api_error(400, "Bu satın alım artık kullanılamıyor.")
        else:
            if consumed:
                raise api_error(400, "Bu satın alım daha önce tamamlanmış.")
            db.execute("INSERT INTO chat_purchases(token_hash,user_id,credited,created) VALUES(?,?,?,?)",
                       (key, user, chat.PRODUCTS[product], int(time.time())))
            chat.credit(db, user, chat.PRODUCTS[product])
    # Credit before consumption. An unconsumed purchase is redelivered on resume.
    # The token record prevents duplicate wallet credit if acknowledgment times out.
    if not consumed:
        try:
            response = google_request("POST", f"/purchases/products/{product}/tokens/{safe_token}:consume")
        except Exception:
            raise api_error(503, "Jeton işlendi. Play onayı sonraki denemede yeniden kontrol edilecek.")
        if response.status_code not in {200, 204}:
            raise api_error(503, "Jeton işlendi. Play onayı sonraki denemede yeniden kontrol edilecek.")
    return {"balance": chat.available(db, user), "restored": recorded is not None}


def reconcile(db):
    if not ENABLED:
        raise RuntimeError("Google Play doğrulama ayarları eksik.")
    count, page = 0, None
    while True:
        params = {"maxResults": 1000, "type": 0}
        if page:
            params["token"] = page
        response = google_request("GET", "/purchases/voidedpurchases", params)
        if response.status_code != 200:
            raise RuntimeError(f"Google Play iade sorgusu başarısız (HTTP {response.status_code}).")
        payload = response.json()
        with db:
            db.execute("BEGIN IMMEDIATE")
            for purchase in payload.get("voidedPurchases", []):
                token = purchase.get("purchaseToken")
                if not token:
                    continue
                key = hashlib.sha256(token.encode()).hexdigest()
                row = db.execute("""SELECT * FROM chat_purchases WHERE token_hash=? AND refunded=0""",
                                 (key,)).fetchone()
                if row is not None:
                    db.execute("UPDATE chat_purchases SET refunded=1 WHERE token_hash=?", (key,))
                    if row["user_id"]:
                        chat.reclaim(db, row["user_id"], row["credited"])
                    count += 1
        page = payload.get("tokenPagination", {}).get("nextPageToken")
        if not page:
            return count
