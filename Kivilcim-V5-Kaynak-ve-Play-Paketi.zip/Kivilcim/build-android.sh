#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mode="${1:-demo}"
if [[ "$mode" == release ]]; then
  if [[ -x ./gradlew ]]; then
    exec ./gradlew :app:bundleRelease
  fi
  exec gradle :app:bundleRelease
fi
if [[ "$mode" != demo ]]; then
  printf 'Usage: %s [demo|release]\n' "$0" >&2
  exit 2
fi
sdk="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
: "${sdk:?Set ANDROID_SDK_ROOT}"
tools="$sdk/build-tools/${ANDROID_BUILD_TOOLS_VERSION:-35.0.0}"
platform="$sdk/platforms/android-36/android.jar"
app="$PWD/app/src/main"
out="$PWD/build/demo"
mkdir -p "$out"
work="$(mktemp -d "$out/tmp.XXXXXXXX")"
trap 'rm -rf -- "$work"' EXIT
mkdir -p "$work/classes" "$work/dex"

sed 's/<manifest /<manifest package="com.kivilcimtopluluk.app.demo" /;s/android:label="Kıvılcım"/android:label="Kıvılcım Deneme"/' \
  "$app/AndroidManifest.xml" > "$work/AndroidManifest.xml"
cat > "$work/BuildConfig.java" <<'JAVA'
package com.kivilcimtopluluk.app;
final class BuildConfig {
    static final boolean DEMO = true;
    static final String ORIGIN = "https://preview.kivilcim.local/";
}
JAVA
"$tools/aapt2" compile --dir "$app/res" -o "$work/resources.zip"
javac --release 8 -classpath "$platform" -d "$work/classes" \
  "$app/java/com/kivilcimtopluluk/app/MainActivity.java" \
  "$PWD/app/src/demo/java/com/kivilcimtopluluk/app/PlayPurchases.java" "$work/BuildConfig.java"
mapfile -t classes < <(find "$work/classes" -name '*.class' -print)
"$tools/d8" --lib "$platform" --min-api 26 --output "$work/dex" "${classes[@]}"
"$tools/aapt2" link -I "$platform" --manifest "$work/AndroidManifest.xml" \
  -A "$app/assets" -o "$work/app.apk" "$work/resources.zip"
(cd "$work/dex" && zip -q -j "$work/app.apk" classes.dex)
"$tools/zipalign" -f 4 "$work/app.apk" "$work/aligned.apk"
demo_keystore="$out/demo-only.jks"
if [[ ! -e "$demo_keystore" ]]; then
  keytool -genkeypair -keystore "$demo_keystore" -storepass android -keypass android \
    -alias demo -keyalg RSA -keysize 2048 -validity 3650 -dname "CN=Kivilcim Local Preview"
fi
"$tools/apksigner" sign --ks "$demo_keystore" --ks-pass pass:android --ks-key-alias demo \
  --v4-signing-enabled false --out "$out/Kivilcim-Deneme.apk" "$work/aligned.apk"
"$tools/apksigner" verify "$out/Kivilcim-Deneme.apk"
printf '%s\n' "$out/Kivilcim-Deneme.apk"
