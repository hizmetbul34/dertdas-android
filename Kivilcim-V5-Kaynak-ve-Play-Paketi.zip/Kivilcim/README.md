# Kıvılcım

Kıvılcım, 18 yaş ve üzeri kullanıcılar için Türkçe bir metin topluluğudur. Günün sorusuna cevap ver, bir kulüpte konu aç veya 15 dakikalık anonim yazışmaya katıl.

## Android denemesi

`Kivilcim-V5-Deneme.apk` telefon içi profil ve topluluk akışlarını, örnek anonim sohbeti ve 100 deneme jetonunu sunar. Deneme eşleşmesi örnek bir sohbetle açılır. Gerçek kullanıcı eşleşmesi ve ödeme canlı sürümde çalışır. Deneme verileri cihaza özeldir. Paket kimliği `com.kivilcimtopluluk.app.demo` ve hedef API 36'dır. Android 8.0 veya sonrası gerekir. Telefon kurulum izni sorarsa yalnızca bu dosyayı açan uygulama için izin verebilirsin.

## Çok kullanıcılı sürüm

- `app/src/main/assets/` telefon ekranlarını içerir. Bu HTML, CSS ve JavaScript dosyaları metin editörüyle değiştirilebilir.
- `server/` hesapları, paylaşımları, yorumları, destekleri, kayıtları, engellemeleri ve bildirimleri işleyen SQLite tabanlı sunucudur. Doğum tarihi yaş kontrolü için işlenir ve veritabanına kaydedilmez.
- Yerel test için ana dizinde `python3 server/app.py` çalıştır ve `http://127.0.0.1:8095` adresini aç. Kullanıcı etkileşimini iki ayrı tarayıcı profiliyle doğrula.
- Yayın için Docker imajını bir HTTPS hizmetine dağıt. Android ve web istemcisiyle sunucu aynı HTTPS kök adresini kullanır. `KIVILCIM_ORIGIN` olarak kök adresi, `KIVILCIM_OPERATOR` olarak işletmeci adını ve `KIVILCIM_CONTACT` olarak takip edilen destek e-postasını gir. `/data` dizinine UID 10001'in yazabildiği kalıcı bir disk bağla. Orada duran SQLite veritabanının yedek ve saklama süreçlerini kur. `/health` sağlık kontrolü adresidir.
- Moderatör önce uygulamada hesap açar. Sunucuda `python3 server/moderator.py KULLANICI_ADI` komutuyla yetki verilir. Profildeki moderasyon kuyruğunda bildirim kapatma, içerik kaldırma ve hesap askıya alma işlemleri yapılır. Aynı komuta `--revoke` ekleyerek yetkiyi kaldırabilirsin.
- Açık web sayfaları `/kurallar`, `/gizlilik`, `/cocuk-guvenligi` ve `/hesap-silme` adreslerinde sunulur. Çocuk güvenliği irtibatı ve bildirim kuyruğunun takibi yayında uygulama işletmecisine aittir. Kaldırma ve yetkili kuruma bildirme süreçleri işletmeci tarafından yürütülür.

## Anonim sohbet ve jetonlar

- Başlatan 25 jeton öder. Gelen eşleşmeyi kabul eden, sohbet gerçekten başladığında günde bir ücretsiz katılım hakkını kullanır. Hak Türkiye saatiyle 00.00’da yenilenir. İki taraf kabul ettikten sonra sunucuda tek işlemle jeton düşülür ve 15 dakikalık süre başlar. Beklerken iptal edilen veya kabul edilmeyen eşleşmelerde jeton kesilmez. Sohbet açıkken iki katılımcı da kendi bakiyesinden 25 jetonla +15 dakika veya 50 jetonla +30 dakika ekleyebilir. Ek süre ortak bitiş saatine eklenir.
- Oda ve süre sunucuda doğrulanır. Kullanıcılar profil adı yerine anonim olarak görünür. Yalnızca metin yazılabilir. Engelleme sohbeti kapatır ve yeni eşleşmeyi engeller. İçerik ya da kullanıcı bildirimleri, moderasyon ekranındaki Sohbet bildirimleri kuyruğuna gider.
- Üretimde sohbeti etkinleştirmek için `KIVILCIM_CHAT_ENABLED=1` ayarlanır. Satış ancak `GOOGLE_APPLICATION_CREDENTIALS` ile Play Android Developer API erişimi olan hizmet hesabı belirlendiğinde görünür. Kimlik bilgisi dosyası yalnızca sunucuda, bir sır deposu veya korumalı disk üzerinden kullanılır.
- Play Console’da aşağıdaki dört tek seferlik, tüketilebilir ürünü oluştur. Her ürün için tekli satın alma seçeneği kullan. Türkiye fiyatını TL olarak gir. Canlı uygulama kullanılabilir paketlerin güncel Play fiyatlarını gösterir. Deneme APK’sındaki mağaza yalnızca deneme jetonu ekler.

| Ürün kimliği | Jeton | Türkiye fiyatı |
| --- | ---: | ---: |
| `kivilcim_jeton_25` | 25 | 50 TL |
| `kivilcim_jeton_50` | 50 | 100 TL |
| `kivilcim_jeton_75` | 75 | 150 TL |
| `kivilcim_jeton_100` | 100 | 200 TL |

- Sunucu tamamlanmış satın almayı, doğru ürünü ve Kıvılcım hesabına ait tanıtıcıyı Google'dan doğrular. Aynı satın alma belirteci tek kez jeton yükler. Tüketim onayı ve iade işleme sunucudan yürür. `python3 server/maintenance.py` komutunu düzenli olarak, örneğin her saat başı, aynı kalıcı veritabanıyla çalıştır. Bu iş normal mesajları 24 saat, bildirim kanıtlarını 30 gün sonra temizler ve Play iadelerini işler.
- Play Console lisans testinde satın alma, bekleyen ödeme, tekrar deneme, iade ve iki farklı hesabın eşleşmesini doğrula. Ürün ve fiyatın Türkiye’de etkin olduğundan emin ol.

## Play için Android App Bundle

Üretim paket kimliği `com.kivilcimtopluluk.app`, sürüm 1.4.0 ve hedef Android 16 (API 36). Bir sonraki sürümde `app/build.gradle` ve deneme manifestindeki sürüm kodunu artır.

JDK 17 veya daha yeni bir sürüm, Android SDK Platform 36 ve Build Tools 35.0.0 gerekir. Üretim derlemesi Gradle 8.11.1 sarmalayıcısını kullanır. Deneme derlemesi için zip gerekir. Play yükleme anahtarını güvenli ve kalıcı olarak sakla. Proje arşivine veya repoya anahtar ve şifre ekleme.

İmzalı AAB, aşağıdaki ortam değişkenleriyle `./build-android.sh release` çalıştırıldığında `app/build/outputs/bundle/release/app-release.aab` konumuna yazılır.

| Değişken | Değer |
| --- | --- |
| `ANDROID_SDK_ROOT` | Android SDK dizini |
| `KIVILCIM_ORIGIN` | Canlı HTTPS kök adresi |
| `KIVILCIM_KEYSTORE` | Play yükleme anahtarını içeren dosyanın yolu |
| `KIVILCIM_KEY_ALIAS` | Anahtar adı |
| `KIVILCIM_KEYSTORE_PASSWORD` | Keystore şifresi |
| `KIVILCIM_KEY_PASSWORD` | Anahtar şifresi |

Deneme APK'sını yeniden üretmek için `ANDROID_SDK_ROOT` ayarlı iken `./build-android.sh demo` çalıştır.

## Play Console

1. Canlı HTTPS sunucusunu ve dört politika sayfasını doğrula. Canlı sunucuda iki test hesabıyla paylaşım, bildirim, engelleme, moderasyon ve hesap silmeyi dene.
2. AAB'yi Play App Signing ile test sürümüne yükle. Mağaza metni ve görseller `magaza/` klasöründe.
3. Play Console’da yetişkin hedef kitle, reşit olmayanların erişimini engelleme, içerik derecelendirmesi, Uygulama erişimi, Veri güvenliği ve çocuk güvenliği alanlarını doldur. Anonim eşleşmeyi ve uygulama içi satın alımları beyan et. Yayımlanmış çocuk güvenliği standartlarını, bildirim noktası ve gizlilik bağlantılarını gir. İnceleme için aktif bir test hesabı oluşturup giriş adımlarını Uygulama erişimi alanına yaz. Veri güvenliği yanıtlarını canlı barındırmanın kayıt, erişim ve saklama uygulamasına göre doğrula.
4. Kendi geliştirici hesabındaki kapalı test ve üretim erişimi koşullarını tamamla.

[Hedef API](https://support.google.com/googleplay/android-developer/answer/11926878) · [Kullanıcıların ürettiği içerik](https://support.google.com/googleplay/android-developer/answer/9876937) · [Çocuk güvenliği](https://support.google.com/googleplay/android-developer/answer/14747720) · [Hesap silme](https://support.google.com/googleplay/android-developer/answer/13327111) · [Play App Signing](https://support.google.com/googleplay/android-developer/answer/9842756)

[Yaş kısıtlı işlevler](https://support.google.com/googleplay/android-developer/answer/16302250) · [Play ödemeleri](https://support.google.com/googleplay/android-developer/answer/9858738) · [Jeton ve Play Billing](https://developer.android.com/google/play/billing/integrate)
